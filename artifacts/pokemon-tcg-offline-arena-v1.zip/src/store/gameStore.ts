import { create } from 'zustand'

import type { CardInstance, ManualStatus, PlayerBoard, SavedDeck, ZoneType } from '@/types/tcg'
import { buildBoardsFromDecks, createEmptyBoards } from '@/utils/game'

type ListZone = Exclude<ZoneType, 'bench' | 'active'>

type GameStore = {
  currentPlayer: PlayerBoard['playerId']
  turnNumber: number
  selectedInstanceId: string | null
  players: ReturnType<typeof createEmptyBoards>
  loadDecks: (
    deckIds: { player1: string | null; player2: string | null },
    decks: Record<string, SavedDeck>,
  ) => void
  nextTurn: () => void
  selectInstance: (instanceId: string | null) => void
  drawCard: (playerId: PlayerBoard['playerId']) => void
  moveCard: (
    fromPlayerId: PlayerBoard['playerId'],
    fromZone: ZoneType,
    instanceId: string,
    toPlayerId: PlayerBoard['playerId'],
    toZone: ZoneType,
    targetIndex?: number,
  ) => void
  adjustDamage: (instanceId: string, delta: number) => void
  adjustEnergy: (instanceId: string, delta: number) => void
  toggleStatus: (instanceId: string, status: ManualStatus) => void
  clearMarkers: (instanceId: string) => void
}

function removeCardFromZone(player: PlayerBoard, zone: ZoneType, instanceId: string) {
  if (zone === 'active' && player.active?.instanceId === instanceId) {
    const removed = player.active
    return {
      player: { ...player, active: null },
      removed,
    }
  }

  if (zone === 'bench') {
    const benchIndex = player.bench.findIndex((card) => card?.instanceId === instanceId)
    if (benchIndex >= 0) {
      const removed = player.bench[benchIndex]
      const bench = [...player.bench]
      bench[benchIndex] = null
      return {
        player: { ...player, bench },
        removed,
      }
    }
  }

  const listZone = zone as ListZone
  const zoneCards = [...player[listZone]]
  const index = zoneCards.findIndex((card) => card.instanceId === instanceId)

  if (index < 0) {
    return { player, removed: null as CardInstance | null }
  }

  const [removed] = zoneCards.splice(index, 1)
  return {
    player: { ...player, [listZone]: zoneCards },
    removed,
  }
}

function addCardToZone(
  player: PlayerBoard,
  zone: ZoneType,
  card: CardInstance,
  targetIndex?: number,
) {
  if (zone === 'active') {
    return { ...player, active: card }
  }

  if (zone === 'bench') {
    const bench = [...player.bench]
    const slot =
      typeof targetIndex === 'number' && targetIndex >= 0 && targetIndex < bench.length
        ? targetIndex
        : bench.findIndex((entry) => entry === null)

    if (slot >= 0) {
      bench[slot] = card
    }

    return { ...player, bench }
  }

  const listZone = zone as ListZone

  return {
    ...player,
    [listZone]:
      listZone === 'deck' ? [card, ...player[listZone]] : [...player[listZone], card],
  }
}

function patchCardInstance(
  players: ReturnType<typeof createEmptyBoards>,
  instanceId: string,
  updater: (card: CardInstance) => CardInstance,
) {
  const nextPlayers = { ...players }

  ;(['player1', 'player2'] as const).forEach((playerId) => {
    const player = nextPlayers[playerId]

    nextPlayers[playerId] = {
      ...player,
      deck: player.deck.map((card) => (card.instanceId === instanceId ? updater(card) : card)),
      hand: player.hand.map((card) => (card.instanceId === instanceId ? updater(card) : card)),
      discard: player.discard.map((card) =>
        card.instanceId === instanceId ? updater(card) : card,
      ),
      prizes: player.prizes.map((card) =>
        card.instanceId === instanceId ? updater(card) : card,
      ),
      bench: player.bench.map((card) => (card?.instanceId === instanceId ? updater(card) : card)),
      active:
        player.active?.instanceId === instanceId ? updater(player.active) : player.active,
    }
  })

  return nextPlayers
}

export const useGameStore = create<GameStore>((set) => ({
  currentPlayer: 'player1',
  turnNumber: 1,
  selectedInstanceId: null,
  players: createEmptyBoards(),
  loadDecks: (deckIds, decks) => {
    const players = buildBoardsFromDecks(deckIds, decks)

    set({
      currentPlayer: 'player1',
      turnNumber: 1,
      selectedInstanceId: null,
      players,
    })
  },
  nextTurn: () =>
    set((state) => ({
      currentPlayer: state.currentPlayer === 'player1' ? 'player2' : 'player1',
      turnNumber: state.turnNumber + 1,
    })),
  selectInstance: (selectedInstanceId) => set({ selectedInstanceId }),
  drawCard: (playerId) =>
    set((state) => {
      const player = state.players[playerId]
      const [nextCard, ...restDeck] = player.deck

      if (!nextCard) {
        return state
      }

      return {
        players: {
          ...state.players,
          [playerId]: {
            ...player,
            deck: restDeck,
            hand: [...player.hand, nextCard],
          },
        },
      }
    }),
  moveCard: (fromPlayerId, fromZone, instanceId, toPlayerId, toZone, targetIndex) =>
    set((state) => {
      const sourceResult = removeCardFromZone(state.players[fromPlayerId], fromZone, instanceId)

      if (!sourceResult.removed) {
        return state
      }

      return {
        players: {
          ...state.players,
          [fromPlayerId]: sourceResult.player,
          [toPlayerId]: addCardToZone(
            fromPlayerId === toPlayerId ? sourceResult.player : state.players[toPlayerId],
            toZone,
            sourceResult.removed,
            targetIndex,
          ),
        },
      }
    }),
  adjustDamage: (instanceId, delta) =>
    set((state) => ({
      players: patchCardInstance(state.players, instanceId, (card) => ({
        ...card,
        damage: Math.max(0, card.damage + delta),
      })),
    })),
  adjustEnergy: (instanceId, delta) =>
    set((state) => ({
      players: patchCardInstance(state.players, instanceId, (card) => ({
        ...card,
        attachedEnergy: Math.max(0, card.attachedEnergy + delta),
      })),
    })),
  toggleStatus: (instanceId, status) =>
    set((state) => ({
      players: patchCardInstance(state.players, instanceId, (card) => ({
        ...card,
        statuses: card.statuses.includes(status)
          ? card.statuses.filter((entry) => entry !== status)
          : [...card.statuses, status],
      })),
    })),
  clearMarkers: (instanceId) =>
    set((state) => ({
      players: patchCardInstance(state.players, instanceId, (card) => ({
        ...card,
        attachedEnergy: 0,
        damage: 0,
        statuses: [],
      })),
    })),
}))
