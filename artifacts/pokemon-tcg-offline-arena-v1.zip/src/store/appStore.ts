import { create } from 'zustand'

import type { AppMode, CardFilterState, SavedDeck, SyncStatus } from '@/types/tcg'

type SyncState = {
  status: SyncStatus
  message: string
  page: number
  totalCards: number
  lastSyncedAt: number | null
}

type AppStore = {
  mode: AppMode
  isOnline: boolean
  sync: SyncState
  selectedCardId: string | null
  filters: CardFilterState
  libraryRefreshToken: number
  decks: SavedDeck[]
  activeDeckId: string | null
  activeDeckName: string
  activeDeckEntries: SavedDeck['cards']
  selectedPlaymatDecks: {
    player1: string | null
    player2: string | null
  }
  setMode: (mode: AppMode) => void
  setOnline: (isOnline: boolean) => void
  setSyncState: (sync: Partial<SyncState>) => void
  setSelectedCardId: (cardId: string | null) => void
  setFilters: (filters: Partial<CardFilterState>) => void
  bumpLibraryRefresh: () => void
  setDecks: (decks: SavedDeck[]) => void
  startDeckDraft: (deck?: SavedDeck) => void
  setDeckName: (name: string) => void
  setActiveDeckEntries: (entries: SavedDeck['cards']) => void
  setSelectedPlaymatDeck: (
    playerId: 'player1' | 'player2',
    deckId: string | null,
  ) => void
}

export const useAppStore = create<AppStore>((set) => ({
  mode: 'sync',
  isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
  sync: {
    status: 'idle',
    message: 'Ready to load local data',
    page: 0,
    totalCards: 0,
    lastSyncedAt: null,
  },
  selectedCardId: null,
  filters: {
    search: '',
    type: '',
    setId: '',
  },
  libraryRefreshToken: 0,
  decks: [],
  activeDeckId: null,
  activeDeckName: 'Untitled Deck',
  activeDeckEntries: [],
  selectedPlaymatDecks: {
    player1: null,
    player2: null,
  },
  setMode: (mode) => set({ mode }),
  setOnline: (isOnline) => set({ isOnline }),
  setSyncState: (sync) =>
    set((state) => ({
      sync: {
        ...state.sync,
        ...sync,
      },
    })),
  setSelectedCardId: (selectedCardId) => set({ selectedCardId }),
  setFilters: (filters) =>
    set((state) => ({
      filters: {
        ...state.filters,
        ...filters,
      },
    })),
  bumpLibraryRefresh: () =>
    set((state) => ({
      libraryRefreshToken: state.libraryRefreshToken + 1,
    })),
  setDecks: (decks) =>
    set((state) => ({
      decks,
      selectedPlaymatDecks: {
        player1: state.selectedPlaymatDecks.player1 ?? decks[0]?.id ?? null,
        player2: state.selectedPlaymatDecks.player2 ?? decks[1]?.id ?? decks[0]?.id ?? null,
      },
    })),
  startDeckDraft: (deck) =>
    set({
      activeDeckId: deck?.id ?? null,
      activeDeckName: deck?.name ?? 'Untitled Deck',
      activeDeckEntries: deck?.cards ?? [],
      mode: 'builder',
    }),
  setDeckName: (activeDeckName) => set({ activeDeckName }),
  setActiveDeckEntries: (activeDeckEntries) => set({ activeDeckEntries }),
  setSelectedPlaymatDeck: (playerId, deckId) =>
    set((state) => ({
      selectedPlaymatDecks: {
        ...state.selectedPlaymatDecks,
        [playerId]: deckId,
      },
    })),
}))
