import { useState } from 'react'
import {
  Archive,
  ClipboardCopy,
  Database,
  Download,
  RefreshCcw,
  Settings2,
  Sparkles,
  Wifi,
  WifiOff,
} from 'lucide-react'

import { CardTile } from '@/components/cards/CardTile'
import type { CachedCard, CachedSet } from '@/types/tcg'

type SyncLibraryViewProps = {
  cards: CachedCard[]
  selectedCard: CachedCard | null
  sets: CachedSet[]
  types: string[]
  counts: {
    cardCount: number
    setCount: number
    deckCount: number
  }
  isOnline: boolean
  syncState: {
    status: string
    message: string
    page: number
    totalCards: number
    lastSyncedAt: number | null
  }
  filters: {
    search: string
    type: string
    setId: string
  }
  selectedSet: CachedSet | null
  selectedSetCardCount: number
  onChangeFilters: (next: Partial<{ search: string; type: string; setId: string }>) => void
  onSelectCard: (cardId: string | null) => void
  onSync: () => void
  onStartDeck: () => void
  onSaveImage: (card: CachedCard) => Promise<void>
  onSaveSetImages: (setId: string) => Promise<void>
  onCopyImage: (card: CachedCard) => Promise<void>
  onOpenSettings: () => void
}

function formatSyncTime(timestamp: number | null) {
  if (!timestamp) {
    return 'Never synced'
  }

  return new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(timestamp)
}

export function SyncLibraryView({
  cards,
  selectedCard,
  sets,
  types,
  counts,
  isOnline,
  syncState,
  filters,
  selectedSet,
  selectedSetCardCount,
  onChangeFilters,
  onSelectCard,
  onSync,
  onStartDeck,
  onSaveImage,
  onSaveSetImages,
  onCopyImage,
  onOpenSettings,
}: SyncLibraryViewProps) {
  const [imageActionBusy, setImageActionBusy] = useState<'download' | 'copy' | 'set' | null>(null)

  async function handleDownloadJpeg() {
    if (!selectedCard) {
      return
    }

    setImageActionBusy('download')

    try {
      await onSaveImage(selectedCard)
    } finally {
      setImageActionBusy(null)
    }
  }

  async function handleCopyImage() {
    if (!selectedCard) {
      return
    }

    setImageActionBusy('copy')

    try {
      await onCopyImage(selectedCard)
    } finally {
      setImageActionBusy(null)
    }
  }

  async function handleSaveSetImages() {
    if (!selectedSet) {
      return
    }

    setImageActionBusy('set')

    try {
      await onSaveSetImages(selectedSet.id)
    } finally {
      setImageActionBusy(null)
    }
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1.1fr_1.6fr_1fr]">
      <section className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-amber-200/70">Phase 1</p>
            <h2 className="mt-2 text-2xl font-semibold text-zinc-50">Offline cache</h2>
          </div>
          <div className="rounded-full border border-white/10 px-3 py-2 text-xs text-zinc-200">
            {isOnline ? <Wifi className="inline size-4" /> : <WifiOff className="inline size-4" />}
          </div>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-3 xl:grid-cols-1">
          <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Cards</p>
            <p className="mt-2 text-3xl font-semibold text-zinc-50">{counts.cardCount}</p>
          </div>
          <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Sets</p>
            <p className="mt-2 text-3xl font-semibold text-zinc-50">{counts.setCount}</p>
          </div>
          <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Decks</p>
            <p className="mt-2 text-3xl font-semibold text-zinc-50">{counts.deckCount}</p>
          </div>
        </div>

        <div className="mt-6 rounded-[1.5rem] border border-amber-200/20 bg-amber-300/10 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-amber-100/75">Sync status</p>
              <p className="mt-2 text-sm text-amber-50">{syncState.message}</p>
              <p className="mt-2 text-xs text-amber-100/75">
                Last updated: {formatSyncTime(syncState.lastSyncedAt)}
              </p>
            </div>
            <button
              type="button"
              onClick={onSync}
              className="inline-flex items-center gap-2 rounded-full border border-amber-200/30 bg-black/20 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-50 transition hover:bg-black/35"
            >
              <RefreshCcw className="size-4" />
              Sync
            </button>
          </div>
          <div className="mt-4 h-2 rounded-full bg-black/20">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-300 to-red-300 transition-all"
              style={{
                width:
                  syncState.status === 'success'
                    ? '100%'
                    : `${Math.min(100, Math.max(8, syncState.page * 3))}%`,
              }}
            />
          </div>
        </div>
      </section>

      <section className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end">
          <label className="flex-1">
            <span className="mb-2 block text-xs uppercase tracking-[0.24em] text-zinc-400">Search</span>
            <input
              value={filters.search}
              onChange={(event) => onChangeFilters({ search: event.target.value })}
              placeholder="Search cached cards"
              className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-zinc-100 outline-none transition focus:border-amber-200/40"
            />
          </label>
          <label>
            <span className="mb-2 block text-xs uppercase tracking-[0.24em] text-zinc-400">Type</span>
            <select
              value={filters.type}
              onChange={(event) => onChangeFilters({ type: event.target.value })}
              className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-zinc-100 outline-none"
            >
              <option value="">All</option>
              {types.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span className="mb-2 block text-xs uppercase tracking-[0.24em] text-zinc-400">Set</span>
            <select
              value={filters.setId}
              onChange={(event) => onChangeFilters({ setId: event.target.value })}
              className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-zinc-100 outline-none"
            >
              <option value="">All</option>
              {sets.map((set) => (
                <option key={set.id} value={set.id}>
                  {set.name}
                </option>
              ))}
            </select>
          </label>
        </div>

        {selectedSet ? (
          <div className="mt-4 rounded-[1.5rem] border border-amber-200/20 bg-amber-300/10 p-4">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.24em] text-amber-100/75">Selected set</p>
                <p className="mt-2 text-sm text-amber-50">
                  Save all {selectedSetCardCount} card images from {selectedSet.name} locally.
                </p>
              </div>
              <button
                type="button"
                onClick={() => void handleSaveSetImages()}
                disabled={imageActionBusy !== null}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-amber-200/30 bg-black/20 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-amber-50 transition hover:bg-black/35 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Archive className="size-4" />
                Save set locally
              </button>
            </div>
          </div>
        ) : null}

        <div className="mt-6 grid max-h-[44rem] grid-cols-2 gap-4 overflow-auto pr-2 lg:grid-cols-3">
          {cards.map((card) => (
            <CardTile
              key={card.id}
              card={card}
              compact
              selected={selectedCard?.id === card.id}
              onClick={() => onSelectCard(card.id)}
            />
          ))}
        </div>
      </section>

      <section className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
        <div className="flex items-center gap-3">
          <Database className="size-5 text-amber-200" />
          <div>
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Cached preview</p>
            <h2 className="text-xl font-semibold text-zinc-50">
              {selectedCard?.name ?? 'Select a card'}
            </h2>
          </div>
        </div>

        <div className="mt-5 space-y-4">
          <button
            type="button"
            onClick={onStartDeck}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-amber-200/30 bg-amber-300/10 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-amber-50 transition hover:bg-amber-300/20"
          >
            <Sparkles className="size-4" />
            Start local deck
          </button>

          {selectedCard ? (
            <>
              <CardTile card={selectedCard} />
              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => void handleDownloadJpeg()}
                  disabled={imageActionBusy !== null}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-white/10 bg-black/20 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-100 transition hover:border-white/20 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <Download className="size-4" />
                  Save JPEG
                </button>
                <button
                  type="button"
                  onClick={() => void handleCopyImage()}
                  disabled={imageActionBusy !== null}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-white/10 bg-black/20 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-100 transition hover:border-white/20 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <ClipboardCopy className="size-4" />
                  Copy image
                </button>
              </div>
              <button
                type="button"
                onClick={onOpenSettings}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-white/10 bg-black/20 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-100 transition hover:border-white/20"
              >
                <Settings2 className="size-4" />
                Save settings
              </button>
              <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4 text-sm text-zinc-300">
                <p>
                  <span className="text-zinc-500">Set:</span> {selectedCard.setName}
                </p>
                <p className="mt-2">
                  <span className="text-zinc-500">Type:</span>{' '}
                  {selectedCard.types.length ? selectedCard.types.join(', ') : 'Colorless'}
                </p>
                <p className="mt-2">
                  <span className="text-zinc-500">Stage:</span> {selectedCard.stage ?? 'Basic'}
                </p>
                <p className="mt-2">
                  <span className="text-zinc-500">Attacks:</span> {selectedCard.attacks.length}
                </p>
              </div>
            </>
          ) : (
            <div className="rounded-[1.5rem] border border-dashed border-white/10 bg-black/20 p-6 text-sm text-zinc-400">
              Start a new local deck any time, or choose a cached card to inspect its offline
              metadata and image actions.
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
