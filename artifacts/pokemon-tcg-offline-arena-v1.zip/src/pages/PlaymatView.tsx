import { AlertCircle, ArrowRightLeft, Hand, SkipForward } from 'lucide-react'

import { CardTile } from '@/components/cards/CardTile'
import { ZoneCardStack } from '@/components/playmat/ZoneCardStack'
import type { CachedCard, CardInstance, ManualStatus, PlayerBoard } from '@/types/tcg'

const manualStatuses: ManualStatus[] = [
  'Asleep',
  'Burned',
  'Confused',
  'Paralyzed',
  'Poisoned',
]

type PlaymatViewProps = {
  cardsById: Record<string, CachedCard>
  decks: Array<{ id: string; name: string }>
  selectedDecks: { player1: string | null; player2: string | null }
  players: Record<PlayerBoard['playerId'], PlayerBoard>
  currentPlayer: PlayerBoard['playerId']
  turnNumber: number
  selectedInstance: { instance: CardInstance; card: CachedCard } | null
  onDeckSelect: (playerId: PlayerBoard['playerId'], deckId: string | null) => void
  onLoadPlaymat: () => void
  onNextTurn: () => void
  onDraw: (playerId: PlayerBoard['playerId']) => void
  onSelectInstance: (instanceId: string | null) => void
  onAdjustDamage: (instanceId: string, delta: number) => void
  onAdjustEnergy: (instanceId: string, delta: number) => void
  onToggleStatus: (instanceId: string, status: ManualStatus) => void
  onClearMarkers: (instanceId: string) => void
  onDragStart: (playerId: PlayerBoard['playerId'], zone: string, instanceId: string) => void
  onDropCard: (playerId: PlayerBoard['playerId'], zone: string, targetIndex?: number) => void
}

function BenchSlot({
  playerId,
  index,
  instance,
  card,
  onSelect,
  onDragStart,
  onDrop,
}: {
  playerId: PlayerBoard['playerId']
  index: number
  instance: CardInstance | null
  card: CachedCard | null
  onSelect: (instanceId: string | null) => void
  onDragStart: (playerId: PlayerBoard['playerId'], zone: string, instanceId: string) => void
  onDrop: (playerId: PlayerBoard['playerId'], zone: string, targetIndex?: number) => void
}) {
  return (
    <div
      onDragOver={(event) => event.preventDefault()}
      onDrop={() => onDrop(playerId, 'bench', index)}
      className="rounded-[1.5rem] border border-white/10 bg-black/20 p-3"
    >
      {instance && card ? (
        <CardTile
          card={card}
          compact
          instance={instance}
          draggable
          onClick={() => onSelect(instance.instanceId)}
          onDragStart={() => onDragStart(playerId, 'bench', instance.instanceId)}
        />
      ) : (
        <button
          type="button"
          onClick={() => onSelect(null)}
          className="flex h-[13.5rem] w-full items-center justify-center rounded-[1.25rem] border border-dashed border-white/10 text-sm text-zinc-500"
        >
          Bench {index + 1}
        </button>
      )}
    </div>
  )
}

function PlayerArea({
  title,
  player,
  cardsById,
  isCurrentPlayer,
  onDraw,
  onSelectInstance,
  onDragStart,
  onDropCard,
}: {
  title: string
  player: PlayerBoard
  cardsById: Record<string, CachedCard>
  isCurrentPlayer: boolean
  onDraw: (playerId: PlayerBoard['playerId']) => void
  onSelectInstance: (instanceId: string | null) => void
  onDragStart: (playerId: PlayerBoard['playerId'], zone: string, instanceId: string) => void
  onDropCard: (playerId: PlayerBoard['playerId'], zone: string, targetIndex?: number) => void
}) {
  const activeCard = player.active ? cardsById[player.active.cardId] : null

  return (
    <section
      className={[
        'rounded-[2rem] border p-5 backdrop-blur',
        isCurrentPlayer
          ? 'border-amber-300/45 bg-amber-300/10'
          : 'border-white/10 bg-white/5',
      ].join(' ')}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">{title}</p>
          <h2 className="mt-1 text-xl font-semibold text-zinc-50">{player.deckName}</h2>
        </div>
        <button
          type="button"
          onClick={() => onDraw(player.playerId)}
          className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/20 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-100 transition hover:border-amber-200/35 hover:text-amber-100"
        >
          <Hand className="size-4" />
          Draw
        </button>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[11rem_1fr_11rem]">
        <div className="space-y-4">
          <ZoneCardStack
            title="Deck"
            cards={player.deck}
            cardsById={cardsById}
            playerId={player.playerId}
            zone="deck"
            onCardClick={onSelectInstance}
            onDragStart={onDragStart}
            onDropCard={onDropCard}
          />
          <ZoneCardStack
            title="Discard"
            cards={player.discard}
            cardsById={cardsById}
            playerId={player.playerId}
            zone="discard"
            onCardClick={onSelectInstance}
            onDragStart={onDragStart}
            onDropCard={onDropCard}
          />
        </div>

        <div className="space-y-4">
          <div
            onDragOver={(event) => event.preventDefault()}
            onDrop={() => onDropCard(player.playerId, 'active')}
            className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4"
          >
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Active spot</p>
            <div className="mt-4 flex justify-center">
              {player.active && activeCard ? (
                <CardTile
                  card={activeCard}
                  instance={player.active}
                  draggable
                  onClick={() => onSelectInstance(player.active?.instanceId ?? null)}
                  onDragStart={() =>
                    onDragStart(player.playerId, 'active', player.active!.instanceId)
                  }
                />
              ) : (
                <div className="flex h-[22rem] w-[15rem] items-center justify-center rounded-[1.5rem] border border-dashed border-white/10 text-zinc-500">
                  Drag a card here
                </div>
              )}
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-5">
            {player.bench.map((instance, index) => (
              <BenchSlot
                key={`${player.playerId}-bench-${index}`}
                playerId={player.playerId}
                index={index}
                instance={instance}
                card={instance ? cardsById[instance.cardId] : null}
                onSelect={onSelectInstance}
                onDragStart={onDragStart}
                onDrop={onDropCard}
              />
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <ZoneCardStack
            title="Prize cards"
            cards={player.prizes}
            cardsById={cardsById}
            playerId={player.playerId}
            zone="prizes"
            onCardClick={onSelectInstance}
            onDragStart={onDragStart}
            onDropCard={onDropCard}
          />
          <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Hand</p>
            <div
              onDragOver={(event) => event.preventDefault()}
              onDrop={() => onDropCard(player.playerId, 'hand')}
              className="mt-3 flex gap-3 overflow-x-auto pb-2"
            >
              {player.hand.length ? (
                player.hand.map((instance) => {
                  const card = cardsById[instance.cardId]
                  return card ? (
                    <CardTile
                      key={instance.instanceId}
                      card={card}
                      compact
                      instance={instance}
                      draggable
                      onClick={() => onSelectInstance(instance.instanceId)}
                      onDragStart={() =>
                        onDragStart(player.playerId, 'hand', instance.instanceId)
                      }
                    />
                  ) : null
                })
              ) : (
                <div className="flex h-[13.5rem] min-w-[9.5rem] items-center justify-center rounded-[1.25rem] border border-dashed border-white/10 text-sm text-zinc-500">
                  Empty hand
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export function PlaymatView({
  cardsById,
  decks,
  selectedDecks,
  players,
  currentPlayer,
  turnNumber,
  selectedInstance,
  onDeckSelect,
  onLoadPlaymat,
  onNextTurn,
  onDraw,
  onSelectInstance,
  onAdjustDamage,
  onAdjustEnergy,
  onToggleStatus,
  onClearMarkers,
  onDragStart,
  onDropCard,
}: PlaymatViewProps) {
  return (
    <div className="space-y-6">
      <section className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-amber-200/70">Phase 3 & 4</p>
            <h2 className="mt-2 text-2xl font-semibold text-zinc-50">Interactive sandbox playmat</h2>
          </div>
          <div className="flex flex-col gap-3 md:flex-row">
            {(['player1', 'player2'] as const).map((playerId) => (
              <label key={playerId}>
                <span className="mb-2 block text-xs uppercase tracking-[0.24em] text-zinc-400">
                  {playerId === 'player1' ? 'Player 1 deck' : 'Player 2 deck'}
                </span>
                <select
                  value={selectedDecks[playerId] ?? ''}
                  onChange={(event) => onDeckSelect(playerId, event.target.value || null)}
                  className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-zinc-100 outline-none"
                >
                  <option value="">No deck</option>
                  {decks.map((deck) => (
                    <option key={deck.id} value={deck.id}>
                      {deck.name}
                    </option>
                  ))}
                </select>
              </label>
            ))}
            <button
              type="button"
              onClick={onLoadPlaymat}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-amber-200/30 bg-amber-300/10 px-4 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-amber-50 transition hover:bg-amber-300/20"
            >
              <ArrowRightLeft className="size-4" />
              Load playmat
            </button>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <div className="rounded-full border border-white/10 bg-black/20 px-4 py-2 text-xs uppercase tracking-[0.24em] text-zinc-100">
            Turn {turnNumber}
          </div>
          <div className="rounded-full border border-amber-300/30 bg-amber-300/10 px-4 py-2 text-xs uppercase tracking-[0.24em] text-amber-100">
            Current player: {currentPlayer === 'player1' ? 'Player 1' : 'Player 2'}
          </div>
          <button
            type="button"
            onClick={onNextTurn}
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/20 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-100 transition hover:border-amber-200/35 hover:text-amber-100"
          >
            <SkipForward className="size-4" />
            Pass turn
          </button>
        </div>
      </section>

      <PlayerArea
        title="Player 2"
        player={players.player2}
        cardsById={cardsById}
        isCurrentPlayer={currentPlayer === 'player2'}
        onDraw={onDraw}
        onSelectInstance={onSelectInstance}
        onDragStart={onDragStart}
        onDropCard={onDropCard}
      />

      <PlayerArea
        title="Player 1"
        player={players.player1}
        cardsById={cardsById}
        isCurrentPlayer={currentPlayer === 'player1'}
        onDraw={onDraw}
        onSelectInstance={onSelectInstance}
        onDragStart={onDragStart}
        onDropCard={onDropCard}
      />

      <section className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
        <div className="flex items-center gap-3">
          <AlertCircle className="size-5 text-amber-200" />
          <div>
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Sandbox controls</p>
            <h3 className="text-xl font-semibold text-zinc-50">
              {selectedInstance?.card.name ?? 'Select any card on the playmat'}
            </h3>
          </div>
        </div>

        {selectedInstance ? (
          <div className="mt-5 grid gap-6 lg:grid-cols-[16rem_1fr]">
            <CardTile card={selectedInstance.card} instance={selectedInstance.instance} />
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
                  <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Damage</p>
                  <div className="mt-3 flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onAdjustDamage(selectedInstance.instance.instanceId, -10)}
                      className="rounded-full border border-white/10 px-3 py-2 text-sm text-zinc-100"
                    >
                      -10
                    </button>
                    <span className="text-2xl font-semibold text-zinc-50">
                      {selectedInstance.instance.damage}
                    </span>
                    <button
                      type="button"
                      onClick={() => onAdjustDamage(selectedInstance.instance.instanceId, 10)}
                      className="rounded-full border border-white/10 px-3 py-2 text-sm text-zinc-100"
                    >
                      +10
                    </button>
                  </div>
                </div>
                <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
                  <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Attached energy</p>
                  <div className="mt-3 flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onAdjustEnergy(selectedInstance.instance.instanceId, -1)}
                      className="rounded-full border border-white/10 px-3 py-2 text-sm text-zinc-100"
                    >
                      -1
                    </button>
                    <span className="text-2xl font-semibold text-zinc-50">
                      {selectedInstance.instance.attachedEnergy}
                    </span>
                    <button
                      type="button"
                      onClick={() => onAdjustEnergy(selectedInstance.instance.instanceId, 1)}
                      className="rounded-full border border-white/10 px-3 py-2 text-sm text-zinc-100"
                    >
                      +1
                    </button>
                  </div>
                </div>
              </div>

              <div className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
                <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">Status conditions</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {manualStatuses.map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() =>
                        onToggleStatus(selectedInstance.instance.instanceId, status)
                      }
                      className={[
                        'rounded-full border px-3 py-2 text-xs font-semibold uppercase tracking-[0.2em] transition',
                        selectedInstance.instance.statuses.includes(status)
                          ? 'border-amber-300/40 bg-amber-300/15 text-amber-100'
                          : 'border-white/10 bg-white/5 text-zinc-200 hover:border-white/20',
                      ].join(' ')}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={() => onClearMarkers(selectedInstance.instance.instanceId)}
                className="rounded-full border border-red-300/30 bg-red-300/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-red-100 transition hover:bg-red-300/20"
              >
                Clear markers
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-5 rounded-[1.5rem] border border-dashed border-white/10 bg-black/20 p-6 text-sm text-zinc-400">
            Click or drag a card from any zone to manage damage counters, energy, and special conditions.
          </div>
        )}
      </section>
    </div>
  )
}
