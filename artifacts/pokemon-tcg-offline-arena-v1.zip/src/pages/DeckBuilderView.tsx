import { Plus, Save, Trash2 } from 'lucide-react'

import { CardTile } from '@/components/cards/CardTile'
import type { CachedCard, SavedDeck } from '@/types/tcg'

type DeckBuilderViewProps = {
  cards: CachedCard[]
  currentDeckCards: Array<{ card: CachedCard; quantity: number }>
  deckName: string
  validation: {
    totalCards: number
    isValid: boolean
    issues: string[]
  }
  decks: SavedDeck[]
  onDeckNameChange: (name: string) => void
  onAddCard: (cardId: string) => void
  onRemoveCard: (cardId: string) => void
  onLoadDeck: (deckId: string) => void
  onDeleteDeck: (deckId: string) => void
  onSaveDeck: () => void
}

export function DeckBuilderView({
  cards,
  currentDeckCards,
  deckName,
  validation,
  decks,
  onDeckNameChange,
  onAddCard,
  onRemoveCard,
  onLoadDeck,
  onDeleteDeck,
  onSaveDeck,
}: DeckBuilderViewProps) {
  return (
    <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
      <section className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-amber-200/70">Phase 2</p>
            <h2 className="mt-2 text-2xl font-semibold text-zinc-50">Offline deck builder</h2>
          </div>
          <button
            type="button"
            onClick={onSaveDeck}
            className="inline-flex items-center gap-2 rounded-full border border-amber-200/30 bg-amber-300/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-50 transition hover:bg-amber-300/20"
          >
            <Save className="size-4" />
            Save deck
          </button>
        </div>

        <div className="mt-5 flex flex-col gap-4 lg:flex-row lg:items-end">
          <label className="flex-1">
            <span className="mb-2 block text-xs uppercase tracking-[0.24em] text-zinc-400">Deck name</span>
            <input
              value={deckName}
              onChange={(event) => onDeckNameChange(event.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-zinc-100 outline-none transition focus:border-amber-200/40"
            />
          </label>
          <div className="rounded-[1.5rem] border border-white/10 bg-black/20 px-4 py-3">
            <p className="text-xs uppercase tracking-[0.24em] text-zinc-500">Deck count</p>
            <p className="mt-1 text-2xl font-semibold text-zinc-50">{validation.totalCards}/60</p>
          </div>
        </div>

        <div className="mt-5 rounded-[1.5rem] border border-white/10 bg-black/20 p-4">
          <p
            className={[
              'text-sm font-medium',
              validation.isValid ? 'text-emerald-300' : 'text-amber-200',
            ].join(' ')}
          >
            {validation.isValid
              ? 'Deck passes the 60-card validation checks.'
              : 'Deck needs adjustments before it is considered valid.'}
          </p>
          {validation.issues.length ? (
            <div className="mt-3 space-y-2 text-sm text-zinc-300">
              {validation.issues.map((issue) => (
                <p key={issue}>{issue}</p>
              ))}
            </div>
          ) : null}
        </div>

        <div className="mt-6 grid max-h-[40rem] grid-cols-2 gap-4 overflow-auto pr-2 lg:grid-cols-3">
          {cards.map((card) => (
            <div key={card.id} className="space-y-2">
              <CardTile card={card} compact />
              <button
                type="button"
                onClick={() => onAddCard(card.id)}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/10 bg-black/20 px-3 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-100 transition hover:border-amber-200/35 hover:text-amber-100"
              >
                <Plus className="size-4" />
                Add
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="space-y-6">
        <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
          <p className="text-xs uppercase tracking-[0.3em] text-amber-200/70">Current list</p>
          <div className="mt-4 max-h-[28rem] space-y-3 overflow-auto pr-1">
            {currentDeckCards.length ? (
              currentDeckCards.map(({ card, quantity }) => (
                <div
                  key={card.id}
                  className="flex items-center justify-between gap-3 rounded-[1.5rem] border border-white/10 bg-black/20 p-3"
                >
                  <div>
                    <p className="text-sm font-semibold text-zinc-100">{card.name}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.18em] text-zinc-400">
                      {card.setName} • {card.types.join(', ') || 'Colorless'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-zinc-100">
                      x{quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => onRemoveCard(card.id)}
                      className="rounded-full border border-white/10 p-2 text-zinc-200 transition hover:border-red-300/30 hover:text-red-200"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="rounded-[1.5rem] border border-dashed border-white/10 bg-black/20 p-5 text-sm text-zinc-400">
                Add cached cards from the library to start a local 60-card deck.
              </div>
            )}
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur">
          <p className="text-xs uppercase tracking-[0.3em] text-amber-200/70">Saved decks</p>
          <div className="mt-4 space-y-3">
            {decks.length ? (
              decks.map((deck) => (
                <div
                  key={deck.id}
                  className="flex items-center justify-between gap-3 rounded-[1.5rem] border border-white/10 bg-black/20 p-4"
                >
                  <div>
                    <p className="text-sm font-semibold text-zinc-100">{deck.name}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.18em] text-zinc-500">
                      {deck.cards.reduce((total, entry) => total + entry.quantity, 0)} cards
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onLoadDeck(deck.id)}
                      className="rounded-full border border-white/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-100 transition hover:border-amber-200/35 hover:text-amber-100"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteDeck(deck.id)}
                      className="rounded-full border border-white/10 p-2 text-zinc-200 transition hover:border-red-300/30 hover:text-red-200"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="rounded-[1.5rem] border border-dashed border-white/10 bg-black/20 p-5 text-sm text-zinc-400">
                Saved decks appear here after you persist them to IndexedDB.
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
