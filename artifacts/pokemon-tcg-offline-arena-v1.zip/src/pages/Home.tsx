import { useCallback, useEffect, useMemo, useRef, useState } from 'react'

import { ActionToast } from '@/components/feedback/ActionToast'
import { ModeTabs } from '@/components/layout/ModeTabs'
import { ExportSettingsModal } from '@/components/settings/ExportSettingsModal'
import { appDb } from '@/db/appDb'
import { DeckBuilderView } from '@/pages/DeckBuilderView'
import { PlaymatView } from '@/pages/PlaymatView'
import { SyncLibraryView } from '@/pages/SyncLibraryView'
import { getCachedCounts, shouldRunInitialSync, syncAllCards } from '@/services/cardSync'
import {
  choosePreferredDirectory,
  clearPreferredDirectory,
  DEFAULT_EXPORT_SETTINGS,
  isPickerAbortError,
  loadExportSettings,
  supportsDirectoryPicker,
  supportsSavePicker,
  updateExportSaveMode,
} from '@/services/exportSettings'
import {
  deleteDeck,
  loadAllCachedCards,
  loadCardsBySetId,
  loadFilterOptions,
  listDecks,
  searchLocalCards,
} from '@/services/localLibrary'
import { useAppStore } from '@/store/appStore'
import { useGameStore } from '@/store/gameStore'
import type {
  CachedCard,
  CachedSet,
  DragPayload,
  ExportSettingsRecord,
  ImageSaveMode,
  SavedDeck,
  ZoneType,
} from '@/types/tcg'
import {
  copyCardImageToClipboard,
  saveCardImageAsJpeg,
  saveSetImagesAsJpegs,
} from '@/utils/cardImageActions'
import { upsertDeckEntry, validateDeck } from '@/utils/deck'
import { createId } from '@/utils/id'

type CountsState = {
  cardCount: number
  setCount: number
  deckCount: number
}

type ToastState = {
  tone: 'success' | 'error' | 'info'
  title: string
  description: string
  actionLabel?: string
  previewUrl?: string
}

export default function Home() {
  const [visibleCards, setVisibleCards] = useState<CachedCard[]>([])
  const [allCards, setAllCards] = useState<CachedCard[]>([])
  const [sets, setSets] = useState<Array<{ id: string; name: string; logo: string | null; symbol: string | null }>>([])
  const [types, setTypes] = useState<string[]>([])
  const [counts, setCounts] = useState<CountsState>({ cardCount: 0, setCount: 0, deckCount: 0 })
  const [exportSettings, setExportSettings] = useState<ExportSettingsRecord>(DEFAULT_EXPORT_SETTINGS)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [toast, setToast] = useState<ToastState | null>(null)
  const dragPayloadRef = useRef<DragPayload | null>(null)

  const {
    mode,
    setMode,
    isOnline,
    setOnline,
    sync,
    setSyncState,
    selectedCardId,
    setSelectedCardId,
    filters,
    setFilters,
    libraryRefreshToken,
    decks,
    setDecks,
    activeDeckId,
    activeDeckName,
    setDeckName,
    activeDeckEntries,
    setActiveDeckEntries,
    startDeckDraft,
    selectedPlaymatDecks,
    setSelectedPlaymatDeck,
  } = useAppStore()

  const {
    players,
    currentPlayer,
    turnNumber,
    selectedInstanceId,
    loadDecks,
    nextTurn,
    selectInstance,
    drawCard,
    moveCard,
    adjustDamage,
    adjustEnergy,
    toggleStatus,
    clearMarkers,
  } = useGameStore()

  const refreshDecks = useCallback(async () => {
    const deckList = await listDecks()
    setDecks(deckList)
  }, [setDecks])

  const showToast = useCallback((nextToast: ToastState) => {
    setToast(nextToast)
  }, [])

  const refreshLibrary = useCallback(async () => {
    const [options, cachedCards, stats, deckList] = await Promise.all([
      loadFilterOptions(),
      loadAllCachedCards(),
      getCachedCounts(),
      listDecks(),
    ])

    setTypes(options.types)
    setSets(options.sets)
    setAllCards(cachedCards)
    setCounts(stats)
    setDecks(deckList)
  }, [setDecks])

  const refreshVisibleCards = useCallback(async () => {
    const cards = await searchLocalCards(filters)
    setVisibleCards(cards)

    if (!selectedCardId && cards[0]) {
      setSelectedCardId(cards[0].id)
    }
  }, [filters, selectedCardId, setSelectedCardId])

  const runSync = useCallback(async () => {
    setSyncState({
      status: 'syncing',
      message: 'Syncing cards from TCGdex...',
      totalCards: 0,
      page: 0,
    })

    try {
      const meta = await syncAllCards((progress) => {
        setSyncState(progress)
      })
      await refreshLibrary()
      await refreshVisibleCards()
      setSyncState({
        status: 'success',
        message: `Synced ${meta.cardCount} English cards`,
        totalCards: meta.cardCount,
        lastSyncedAt: meta.lastSyncedAt,
      })
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown sync error'
      setSyncState({
        status: 'error',
        message,
      })
    }
  }, [refreshLibrary, refreshVisibleCards, setSyncState])

  useEffect(() => {
    const handleOnline = () => setOnline(true)
    const handleOffline = () => setOnline(false)

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [setOnline])

  useEffect(() => {
    const boot = async () => {
      const [settings] = await Promise.all([loadExportSettings(), refreshLibrary(), refreshVisibleCards()])
      setExportSettings(settings)

      const [meta, needsSync] = await Promise.all([appDb.syncMeta.get('cards'), shouldRunInitialSync()])

      if (meta) {
        setSyncState({
          status: 'success',
          message: `Loaded ${meta.cardCount} cached cards`,
          totalCards: meta.cardCount,
          lastSyncedAt: meta.lastSyncedAt,
        })
      }

      if (needsSync && navigator.onLine) {
        await runSync()
      }
    }

    void boot()
  }, [refreshLibrary, refreshVisibleCards, runSync, setSyncState])

  useEffect(() => {
    if (!toast) {
      return
    }

    const timeoutId = window.setTimeout(() => {
      setToast(null)
    }, 6000)

    return () => {
      window.clearTimeout(timeoutId)
    }
  }, [toast])

  useEffect(() => {
    return () => {
      if (toast?.previewUrl) {
        URL.revokeObjectURL(toast.previewUrl)
      }
    }
  }, [toast])

  useEffect(() => {
    void refreshVisibleCards()
  }, [filters, libraryRefreshToken, refreshVisibleCards])

  const cardsById = useMemo(
    () =>
      allCards.reduce<Record<string, CachedCard>>((accumulator, card) => {
        accumulator[card.id] = card
        return accumulator
      }, {}),
    [allCards],
  )

  const selectedCard = selectedCardId ? cardsById[selectedCardId] ?? null : null
  const selectedSet = useMemo<CachedSet | null>(
    () => sets.find((set) => set.id === filters.setId) ?? null,
    [filters.setId, sets],
  )
  const selectedSetCardCount = useMemo(
    () => (filters.setId ? allCards.filter((card) => card.setId === filters.setId).length : 0),
    [allCards, filters.setId],
  )
  const currentDeckCards = useMemo(
    () =>
      activeDeckEntries
        .map((entry) => ({
          card: cardsById[entry.cardId],
          quantity: entry.quantity,
        }))
        .filter((entry): entry is { card: CachedCard; quantity: number } => Boolean(entry.card)),
    [activeDeckEntries, cardsById],
  )
  const deckValidation = useMemo(
    () => validateDeck(activeDeckEntries, cardsById),
    [activeDeckEntries, cardsById],
  )
  const decksById = useMemo(
    () =>
      decks.reduce<Record<string, SavedDeck>>((accumulator, deck) => {
        accumulator[deck.id] = deck
        return accumulator
      }, {}),
    [decks],
  )
  const selectedInstance = useMemo(() => {
    if (!selectedInstanceId) {
      return null
    }

    const zones = [
      ...players.player1.deck,
      ...players.player1.hand,
      ...players.player1.discard,
      ...players.player1.prizes,
      ...players.player1.bench.filter(Boolean),
      ...(players.player1.active ? [players.player1.active] : []),
      ...players.player2.deck,
      ...players.player2.hand,
      ...players.player2.discard,
      ...players.player2.prizes,
      ...players.player2.bench.filter(Boolean),
      ...(players.player2.active ? [players.player2.active] : []),
    ]

    const instance = zones.find((entry) => entry?.instanceId === selectedInstanceId)

    if (!instance) {
      return null
    }

    const card = cardsById[instance.cardId]
    return card ? { instance, card } : null
  }, [cardsById, players, selectedInstanceId])

  const handleSaveDeck = useCallback(async () => {
    const existing = activeDeckId ? decksById[activeDeckId] : null
    const timestamp = Date.now()

    const savedDeck = structuredClone({
      id: existing?.id ?? createId('deck'),
      name: activeDeckName.trim() || 'Untitled Deck',
      cards: activeDeckEntries,
      createdAt: existing?.createdAt ?? timestamp,
      updatedAt: timestamp,
    })

    try {
      await appDb.decks.put(savedDeck)
      startDeckDraft(savedDeck)
      await refreshDecks()
      const stats = await getCachedCounts()
      setCounts(stats)
    } catch (error) {
      setSyncState({
        status: 'error',
        message: error instanceof Error ? error.message : 'Failed to save deck',
      })
    }
  }, [
    activeDeckEntries,
    activeDeckId,
    activeDeckName,
    decksById,
    refreshDecks,
    setSyncState,
    startDeckDraft,
  ])

  const handleDeleteDeck = useCallback(
    async (deckId: string) => {
      await deleteDeck(deckId)
      await refreshDecks()
      const stats = await getCachedCounts()
      setCounts(stats)
    },
    [refreshDecks],
  )

  const handleLoadDeck = useCallback(
    (deckId: string) => {
      const deck = decksById[deckId]
      if (deck) {
        startDeckDraft(deck)
      }
    },
    [decksById, startDeckDraft],
  )

  const handleSaveModeChange = useCallback(
    async (saveMode: ImageSaveMode) => {
      const nextSettings = await updateExportSaveMode(exportSettings, saveMode)
      setExportSettings(nextSettings)
    },
    [exportSettings],
  )

  const handleChoosePreferredDirectory = useCallback(async () => {
    try {
      const nextSettings = await choosePreferredDirectory(exportSettings)
      setExportSettings(nextSettings)
      showToast({
        tone: 'success',
        title: 'Save folder updated',
        description: `Card images now use ${nextSettings.preferredDirectoryName ?? 'your chosen folder'}.`,
      })
    } catch (error) {
      if (isPickerAbortError(error)) {
        return
      }

      showToast({
        tone: 'error',
        title: 'Folder selection failed',
        description:
          error instanceof Error ? error.message : 'Unable to choose a preferred save folder.',
      })
    }
  }, [exportSettings, showToast])

  const handleClearPreferredDirectory = useCallback(async () => {
    const nextSettings = await clearPreferredDirectory(exportSettings)
    setExportSettings(nextSettings)
    showToast({
      tone: 'success',
      title: 'Preferred folder cleared',
      description: 'Card image saves now use the browser download flow.',
    })
  }, [exportSettings, showToast])

  const handleSaveImage = useCallback(
    async (card: CachedCard) => {
      try {
        const result = await saveCardImageAsJpeg(card, exportSettings)
        showToast({
          tone: 'success',
          title: 'Image saved',
          description: `${result.fileName} was saved to ${result.locationLabel}.`,
          actionLabel: 'View now',
          previewUrl: result.previewUrl,
        })
      } catch (error) {
        if (isPickerAbortError(error)) {
          return
        }

        showToast({
          tone: 'error',
          title: 'Save failed',
          description: error instanceof Error ? error.message : 'Unable to save the image.',
        })
      }
    },
    [exportSettings, showToast],
  )

  const handleSaveSetImages = useCallback(
    async (setId: string) => {
      const set = sets.find((entry) => entry.id === setId)

      if (!set) {
        showToast({
          tone: 'error',
          title: 'Set not found',
          description: 'Choose a valid set before saving all images locally.',
        })
        return
      }

      showToast({
        tone: 'info',
        title: 'Saving set images',
        description: `Preparing ${set.name} for local export.`,
      })

      try {
        const cards = await loadCardsBySetId(setId)
        const result = await saveSetImagesAsJpegs(cards, exportSettings, set.name)

        showToast({
          tone: 'success',
          title: 'Set saved locally',
          description: `Saved ${result.savedCount} images from ${set.name} to ${result.locationLabel}.`,
        })
      } catch (error) {
        showToast({
          tone: 'error',
          title: 'Set export failed',
          description: error instanceof Error ? error.message : 'Unable to save this set locally.',
        })
      }
    },
    [exportSettings, sets, showToast],
  )

  const handleCopyImage = useCallback(
    async (card: CachedCard) => {
      try {
        await copyCardImageToClipboard(card)
        showToast({
          tone: 'success',
          title: 'Image copied',
          description: `${card.name} was copied to the clipboard as a JPEG image.`,
        })
      } catch (error) {
        showToast({
          tone: 'error',
          title: 'Copy failed',
          description: error instanceof Error ? error.message : 'Unable to copy the image.',
        })
      }
    },
    [showToast],
  )

  const handleDragStart = useCallback(
    (playerId: 'player1' | 'player2', zone: string, instanceId: string) => {
      dragPayloadRef.current = {
        playerId,
        zone: zone as ZoneType,
        instanceId,
      }
    },
    [],
  )

  const handleDropCard = useCallback(
    (playerId: 'player1' | 'player2', zone: string, targetIndex?: number) => {
      const payload = dragPayloadRef.current

      if (!payload) {
        return
      }

      moveCard(payload.playerId, payload.zone, payload.instanceId, playerId, zone as ZoneType, targetIndex)
      dragPayloadRef.current = null
    },
    [moveCard],
  )

  return (
    <div className="min-h-screen bg-[#120f0b] text-zinc-100">
      <div className="mx-auto flex min-h-screen max-w-[1800px] flex-col gap-6 px-4 py-6 md:px-6 xl:px-8">
        <header className="rounded-[2rem] border border-white/10 bg-[radial-gradient(circle_at_top,rgba(250,204,21,0.14),transparent_35%),linear-gradient(180deg,rgba(39,39,42,0.85),rgba(9,9,11,0.95))] p-6 shadow-[0_28px_90px_rgba(0,0,0,0.35)]">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.4em] text-amber-200/70">Trae Builder Mode</p>
              <h1 className="mt-3 text-4xl font-semibold text-zinc-50 md:text-5xl">
                Pokemon TCG Offline Arena
              </h1>
              <p className="mt-3 max-w-3xl text-sm leading-relaxed text-zinc-300">
                A browser-only replica with Dexie storage, local deck building, a responsive
                sandbox playmat, and a fallback card face that stays playable when art is
                unavailable.
              </p>
              <div className="mt-4 flex flex-wrap gap-3">
                <a
                  href="/downloads/pokemon-tcg-offline-arena-v1.zip"
                  download
                  className="inline-flex items-center justify-center rounded-full border border-amber-300/30 bg-amber-300/10 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-amber-50 transition hover:bg-amber-300/20"
                >
                  Download V1 Zip
                </a>
                <a
                  href="/downloads/"
                  className="inline-flex items-center justify-center rounded-full border border-white/10 bg-black/20 px-4 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-100 transition hover:border-white/20"
                >
                  Open Downloads
                </a>
              </div>
            </div>
            <div className="rounded-[1.5rem] border border-white/10 bg-black/20 px-5 py-4">
              <p className="text-xs uppercase tracking-[0.28em] text-zinc-500">Current cache state</p>
              <p className="mt-2 text-lg font-semibold text-zinc-50">{sync.message}</p>
            </div>
          </div>

          <div className="mt-6">
            <ModeTabs mode={mode} onChange={setMode} />
          </div>
        </header>

        {mode === 'sync' ? (
          <SyncLibraryView
            cards={visibleCards}
            selectedCard={selectedCard}
            sets={sets}
            types={types}
            counts={counts}
            isOnline={isOnline}
            syncState={sync}
            filters={filters}
            selectedSet={selectedSet}
            selectedSetCardCount={selectedSetCardCount}
            onChangeFilters={setFilters}
            onSelectCard={setSelectedCardId}
            onSync={() => void runSync()}
            onStartDeck={() => startDeckDraft()}
            onSaveImage={handleSaveImage}
            onSaveSetImages={handleSaveSetImages}
            onCopyImage={handleCopyImage}
            onOpenSettings={() => setSettingsOpen(true)}
          />
        ) : null}

        {mode === 'builder' ? (
          <DeckBuilderView
            cards={visibleCards}
            currentDeckCards={currentDeckCards}
            deckName={activeDeckName}
            validation={deckValidation}
            decks={decks}
            onDeckNameChange={setDeckName}
            onAddCard={(cardId) => setActiveDeckEntries(upsertDeckEntry(activeDeckEntries, cardId, 1))}
            onRemoveCard={(cardId) =>
              setActiveDeckEntries(upsertDeckEntry(activeDeckEntries, cardId, -1))
            }
            onLoadDeck={handleLoadDeck}
            onDeleteDeck={(deckId) => void handleDeleteDeck(deckId)}
            onSaveDeck={() => void handleSaveDeck()}
          />
        ) : null}

        {mode === 'playmat' ? (
          <PlaymatView
            cardsById={cardsById}
            decks={decks.map((deck) => ({ id: deck.id, name: deck.name }))}
            selectedDecks={selectedPlaymatDecks}
            players={players}
            currentPlayer={currentPlayer}
            turnNumber={turnNumber}
            selectedInstance={selectedInstance}
            onDeckSelect={setSelectedPlaymatDeck}
            onLoadPlaymat={() => loadDecks(selectedPlaymatDecks, decksById)}
            onNextTurn={nextTurn}
            onDraw={drawCard}
            onSelectInstance={selectInstance}
            onAdjustDamage={adjustDamage}
            onAdjustEnergy={adjustEnergy}
            onToggleStatus={toggleStatus}
            onClearMarkers={clearMarkers}
            onDragStart={handleDragStart}
            onDropCard={handleDropCard}
          />
        ) : null}
      </div>

      <ExportSettingsModal
        isOpen={settingsOpen}
        settings={exportSettings}
        supportsDirectorySelection={supportsDirectoryPicker()}
        supportsSavePicker={supportsSavePicker()}
        onClose={() => setSettingsOpen(false)}
        onSaveModeChange={(saveMode) => void handleSaveModeChange(saveMode)}
        onChooseFolder={() => void handleChoosePreferredDirectory()}
        onClearFolder={() => void handleClearPreferredDirectory()}
      />

      {toast ? (
        <ActionToast
          tone={toast.tone}
          title={toast.title}
          description={toast.description}
          actionLabel={toast.actionLabel}
          onAction={
            toast.previewUrl
              ? () => {
                  window.open(toast.previewUrl, '_blank', 'noopener,noreferrer')
                  setToast(null)
                }
              : undefined
          }
          onDismiss={() => setToast(null)}
        />
      ) : null}
    </div>
  )
}
