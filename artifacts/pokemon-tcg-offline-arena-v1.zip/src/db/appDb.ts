import Dexie, { type Table } from 'dexie'

import type { CachedCard, CachedSet, ExportSettingsRecord, SavedDeck, SyncMeta } from '@/types/tcg'

export class PokemonTcgDexie extends Dexie {
  cards!: Table<CachedCard, string>
  sets!: Table<CachedSet, string>
  decks!: Table<SavedDeck, string>
  syncMeta!: Table<SyncMeta, string>
  settings!: Table<ExportSettingsRecord, string>

  constructor() {
    super('pokemon-tcg-offline')

    this.version(1).stores({
      cards:
        'id, name, setId, setName, category, regulationMark, stage, energyType, *types, cachedAt',
      sets: 'id, name',
      decks: 'id, name, updatedAt',
      syncMeta: 'key, lastSyncedAt',
    })

    this.version(2).stores({
      cards:
        'id, name, setId, setName, category, regulationMark, stage, energyType, *types, cachedAt',
      sets: 'id, name',
      decks: 'id, name, updatedAt',
      syncMeta: 'key, lastSyncedAt',
      settings: 'key',
    })
  }
}

export const appDb = new PokemonTcgDexie()
