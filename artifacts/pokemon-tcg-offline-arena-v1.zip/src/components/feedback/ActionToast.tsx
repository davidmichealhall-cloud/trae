import { CheckCircle2, ExternalLink, XCircle } from 'lucide-react'

type ActionToastProps = {
  tone: 'success' | 'error' | 'info'
  title: string
  description: string
  actionLabel?: string
  onAction?: () => void
  onDismiss: () => void
}

export function ActionToast({
  tone,
  title,
  description,
  actionLabel,
  onAction,
  onDismiss,
}: ActionToastProps) {
  const isSuccess = tone === 'success'

  return (
    <div className="fixed bottom-4 right-4 z-50 w-[min(24rem,calc(100vw-2rem))] rounded-[1.5rem] border border-white/10 bg-zinc-950/95 p-4 shadow-[0_24px_60px_rgba(0,0,0,0.45)] backdrop-blur">
      <div className="flex items-start gap-3">
        <div className="mt-0.5">
          {isSuccess ? (
            <CheckCircle2 className="size-5 text-emerald-300" />
          ) : (
            <XCircle className="size-5 text-red-300" />
          )}
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-zinc-50">{title}</p>
          <p className="mt-1 text-sm text-zinc-300">{description}</p>
          <div className="mt-3 flex items-center gap-3">
            {actionLabel && onAction ? (
              <button
                type="button"
                onClick={onAction}
                className="inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-300/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-amber-50 transition hover:bg-amber-300/20"
              >
                <ExternalLink className="size-4" />
                {actionLabel}
              </button>
            ) : null}
            <button
              type="button"
              onClick={onDismiss}
              className="text-xs font-semibold uppercase tracking-[0.18em] text-zinc-400 transition hover:text-zinc-200"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
