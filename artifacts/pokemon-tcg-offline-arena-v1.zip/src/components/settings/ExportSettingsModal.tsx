import { FolderOpen, Settings, X } from 'lucide-react'

import type { ExportSettingsRecord, ImageSaveMode } from '@/types/tcg'

type ExportSettingsModalProps = {
  isOpen: boolean
  settings: ExportSettingsRecord
  supportsDirectorySelection: boolean
  supportsSavePicker: boolean
  onClose: () => void
  onSaveModeChange: (saveMode: ImageSaveMode) => void
  onChooseFolder: () => void
  onClearFolder: () => void
}

const SAVE_MODE_OPTIONS: Array<{
  value: ImageSaveMode
  label: string
  description: string
}> = [
  {
    value: 'browser-download',
    label: 'Browser downloads',
    description: 'Uses the browser download flow and your browser default download location.',
  },
  {
    value: 'ask-every-time',
    label: 'Ask every time',
    description: 'Opens a save dialog for each card image when the browser supports it.',
  },
  {
    value: 'preferred-folder',
    label: 'Preferred folder',
    description: 'Saves directly into a folder you choose in settings when the browser allows it.',
  },
]

export function ExportSettingsModal({
  isOpen,
  settings,
  supportsDirectorySelection,
  supportsSavePicker,
  onClose,
  onSaveModeChange,
  onChooseFolder,
  onClearFolder,
}: ExportSettingsModalProps) {
  if (!isOpen) {
    return null
  }

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 px-4 py-6 backdrop-blur">
      <div className="w-full max-w-2xl rounded-[2rem] border border-white/10 bg-[#18120d] p-6 shadow-[0_28px_90px_rgba(0,0,0,0.45)]">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <Settings className="size-5 text-amber-200" />
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-zinc-500">Settings</p>
              <h2 className="text-2xl font-semibold text-zinc-50">Image save options</h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-white/10 bg-black/20 p-2 text-zinc-300 transition hover:border-white/20 hover:text-zinc-100"
            aria-label="Close settings"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="mt-6 space-y-3">
          {SAVE_MODE_OPTIONS.map((option) => {
            const disabled =
              (option.value === 'ask-every-time' && !supportsSavePicker) ||
              (option.value === 'preferred-folder' && !supportsDirectorySelection)

            return (
              <label
                key={option.value}
                className={[
                  'flex cursor-pointer items-start gap-3 rounded-[1.5rem] border p-4 transition',
                  settings.saveMode === option.value
                    ? 'border-amber-300/45 bg-amber-300/10'
                    : 'border-white/10 bg-black/20',
                  disabled ? 'cursor-not-allowed opacity-50' : 'hover:border-white/20',
                ].join(' ')}
              >
                <input
                  type="radio"
                  name="image-save-mode"
                  value={option.value}
                  checked={settings.saveMode === option.value}
                  disabled={disabled}
                  onChange={() => onSaveModeChange(option.value)}
                  className="mt-1"
                />
                <div>
                  <p className="text-sm font-semibold text-zinc-50">{option.label}</p>
                  <p className="mt-1 text-sm text-zinc-300">{option.description}</p>
                  {disabled ? (
                    <p className="mt-2 text-xs uppercase tracking-[0.18em] text-zinc-500">
                      Not supported by this browser
                    </p>
                  ) : null}
                </div>
              </label>
            )
          })}
        </div>

        <div className="mt-6 rounded-[1.5rem] border border-white/10 bg-black/20 p-5">
          <p className="text-sm font-semibold text-zinc-50">Location control</p>
          <p className="mt-2 text-sm text-zinc-300">
            This app can only change the save location when your browser supports file or folder
            pickers.
          </p>
          <p className="mt-3 text-sm text-zinc-300">
            Save As support: {supportsSavePicker ? 'available' : 'not available in this browser'}
          </p>
          <p className="mt-2 text-sm text-zinc-300">
            Remember folder support:{' '}
            {supportsDirectorySelection ? 'available' : 'not available in this browser'}
          </p>
          {!supportsSavePicker && !supportsDirectorySelection ? (
            <p className="mt-4 text-sm text-zinc-400">
              In this browser, downloads always use the browser-managed download location. To
              change where files go, use your browser download settings instead of this app.
            </p>
          ) : null}
        </div>

        <div className="mt-6 rounded-[1.5rem] border border-white/10 bg-black/20 p-5">
          <div className="flex items-center gap-3">
            <FolderOpen className="size-5 text-amber-200" />
            <div>
              <p className="text-sm font-semibold text-zinc-50">Preferred save folder</p>
              <p className="mt-1 text-sm text-zinc-300">
                {settings.preferredDirectoryName
                  ? `Current folder: ${settings.preferredDirectoryName}`
                  : 'No preferred folder selected yet.'}
              </p>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={onChooseFolder}
              disabled={!supportsDirectorySelection}
              className="inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-300/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-amber-50 transition hover:bg-amber-300/20 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <FolderOpen className="size-4" />
              {settings.preferredDirectoryName ? 'Change folder' : 'Choose folder'}
            </button>
            <button
              type="button"
              onClick={onClearFolder}
              disabled={!settings.preferredDirectoryName}
              className="rounded-full border border-white/10 bg-black/20 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-zinc-200 transition hover:border-white/20 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Clear folder
            </button>
          </div>

          {!supportsDirectorySelection ? (
            <p className="mt-4 text-sm text-zinc-400">
              This browser does not let the app remember a folder. Use browser download settings,
              or switch to Ask every time if Save As is available above.
            </p>
          ) : null}
        </div>
      </div>
    </div>
  )
}
