import type { CachedCard } from '@/types/tcg'

type OfflineCardFaceProps = {
  card: CachedCard
  compact?: boolean
}

export function OfflineCardFace({ card, compact = false }: OfflineCardFaceProps) {
  return (
    <div
      className={[
        'relative flex h-full w-full flex-col overflow-hidden rounded-[1.25rem] border border-amber-200/30',
        'bg-[radial-gradient(circle_at_top,rgba(250,204,21,0.18),transparent_35%),linear-gradient(180deg,rgba(24,24,27,0.92),rgba(12,10,9,0.98))]',
        compact ? 'p-3' : 'p-4',
      ].join(' ')}
    >
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.08),transparent_38%,transparent_62%,rgba(255,255,255,0.06))]" />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <p className={compact ? 'text-[11px] uppercase tracking-[0.3em] text-amber-200/70' : 'text-xs uppercase tracking-[0.35em] text-amber-200/70'}>
            Offline Cache
          </p>
          <h3 className={compact ? 'mt-1 text-sm font-semibold text-amber-50' : 'mt-1 text-lg font-semibold text-amber-50'}>
            {card.name}
          </h3>
        </div>
        <div className="rounded-full border border-amber-300/40 bg-amber-200/10 px-3 py-1 text-[11px] font-semibold text-amber-100">
          HP {card.hp ?? '--'}
        </div>
      </div>

      <div className="relative mt-3 flex flex-wrap gap-2">
        {(card.types.length ? card.types : ['Colorless']).map((type) => (
          <span
            key={type}
            className="rounded-full border border-amber-100/20 bg-white/5 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-zinc-100"
          >
            {type}
          </span>
        ))}
        <span className="rounded-full border border-red-300/25 bg-red-300/10 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-red-100">
          {card.setName}
        </span>
      </div>

      <div className="relative mt-3 space-y-2">
        {(card.attacks.length ? card.attacks : [{ name: 'No attack data', cost: [], damage: null, effect: null }]).slice(0, compact ? 1 : 3).map((attack) => (
          <div key={attack.name} className="rounded-2xl border border-white/10 bg-black/20 p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-semibold text-amber-50">{attack.name}</p>
              {attack.damage ? (
                <span className="text-xs font-semibold text-amber-200">{attack.damage}</span>
              ) : null}
            </div>
            {attack.cost.length ? (
              <p className="mt-2 text-[10px] uppercase tracking-[0.2em] text-zinc-400">
                Cost: {attack.cost.join(' • ')}
              </p>
            ) : null}
            {attack.effect && !compact ? (
              <p className="mt-2 line-clamp-3 text-[11px] leading-relaxed text-zinc-300">
                {attack.effect}
              </p>
            ) : null}
          </div>
        ))}
      </div>

      {!compact ? (
        <div className="relative mt-auto pt-3 text-[10px] uppercase tracking-[0.28em] text-zinc-500">
          {card.category} • {card.stage ?? 'Basic'}
        </div>
      ) : null}
    </div>
  )
}
