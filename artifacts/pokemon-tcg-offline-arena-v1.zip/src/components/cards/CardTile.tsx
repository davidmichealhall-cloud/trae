import { useMemo, useState } from 'react'

import { OfflineCardFace } from '@/components/cards/OfflineCardFace'
import type { CachedCard, CardInstance } from '@/types/tcg'
import { resolveTcgdexImageUrl } from '@/utils/images'

type CardTileProps = {
  card: CachedCard
  compact?: boolean
  selected?: boolean
  instance?: CardInstance
  draggable?: boolean
  onClick?: () => void
  onDragStart?: () => void
}

export function CardTile({
  card,
  compact = false,
  selected = false,
  instance,
  draggable = false,
  onClick,
  onDragStart,
}: CardTileProps) {
  const [imageFailed, setImageFailed] = useState(false)
  const badges = useMemo(() => {
    const parts = [card.setName]

    if (card.types.length) {
      parts.push(card.types.join(' / '))
    }

    return parts.join(' • ')
  }, [card.setName, card.types])
  const resolvedImageUrl = useMemo(
    () => resolveTcgdexImageUrl(card.imageUrl),
    [card.imageUrl],
  )

  return (
    <button
      type="button"
      draggable={draggable}
      onDragStart={onDragStart}
      onClick={onClick}
      className={[
        'group relative overflow-hidden rounded-[1.5rem] border text-left transition duration-300',
        compact ? 'h-[13.5rem] w-[9.5rem]' : 'h-[22rem] w-[15rem]',
        selected
          ? 'border-amber-300/70 shadow-[0_0_0_1px_rgba(252,211,77,0.55),0_18px_40px_rgba(0,0,0,0.4)]'
          : 'border-white/10 shadow-[0_18px_40px_rgba(0,0,0,0.3)] hover:-translate-y-1 hover:border-amber-100/40 hover:shadow-[0_22px_60px_rgba(0,0,0,0.45)]',
      ].join(' ')}
    >
      {resolvedImageUrl && !imageFailed ? (
        <>
          <img
            src={resolvedImageUrl}
            alt={card.name}
            className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.04]"
            onError={() => setImageFailed(true)}
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/70 to-transparent p-3">
            <p className="text-sm font-semibold text-white">{card.name}</p>
            <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-zinc-300">{badges}</p>
          </div>
        </>
      ) : (
        <OfflineCardFace card={card} compact={compact} />
      )}

      {instance ? (
        <div className="absolute left-3 top-3 rounded-full border border-white/10 bg-black/70 px-2 py-1 text-[10px] uppercase tracking-[0.15em] text-zinc-100 backdrop-blur">
          {instance.damage ? `${instance.damage} dmg` : 'Ready'}
          {instance.attachedEnergy ? ` • ${instance.attachedEnergy} energy` : ''}
        </div>
      ) : null}
    </button>
  )
}
