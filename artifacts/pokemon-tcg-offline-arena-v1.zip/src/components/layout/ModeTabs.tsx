import type { AppMode } from '@/types/tcg'

const tabs: Array<{ id: AppMode; label: string; blurb: string }> = [
  { id: 'sync', label: 'Sync & Library', blurb: 'Cache and browse cards offline' },
  { id: 'builder', label: 'Deck Builder', blurb: 'Assemble and save 60-card decks' },
  { id: 'playmat', label: 'Playmat', blurb: 'Run local sandbox matches' },
]

type ModeTabsProps = {
  mode: AppMode
  onChange: (mode: AppMode) => void
}

export function ModeTabs({ mode, onChange }: ModeTabsProps) {
  return (
    <div className="grid gap-3 md:grid-cols-3">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          type="button"
          onClick={() => onChange(tab.id)}
          className={[
            'rounded-[1.5rem] border p-4 text-left transition',
            mode === tab.id
              ? 'border-amber-300/70 bg-amber-300/10 shadow-[0_16px_40px_rgba(250,204,21,0.08)]'
              : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10',
          ].join(' ')}
        >
          <p className="text-xs uppercase tracking-[0.3em] text-amber-200/70">{tab.label}</p>
          <p className="mt-2 text-sm text-zinc-200">{tab.blurb}</p>
        </button>
      ))}
    </div>
  )
}
