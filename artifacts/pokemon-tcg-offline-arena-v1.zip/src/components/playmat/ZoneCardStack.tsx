import { Layers3 } from 'lucide-react'

import type { CardInstance, CachedCard, PlayerBoard, ZoneType } from '@/types/tcg'

type ZoneCardStackProps = {
  title: string
  cards: CardInstance[]
  cardsById: Record<string, CachedCard>
  playerId: PlayerBoard['playerId']
  zone: Exclude<ZoneType, 'bench' | 'active'>
  onCardClick: (instanceId: string | null) => void
  onDragStart: (playerId: PlayerBoard['playerId'], zone: ZoneType, instanceId: string) => void
  onDropCard: (
    playerId: PlayerBoard['playerId'],
    zone: ZoneType,
    targetIndex?: number,
  ) => void
}

export function ZoneCardStack({
  title,
  cards,
  cardsById,
  playerId,
  zone,
  onCardClick,
  onDragStart,
  onDropCard,
}: ZoneCardStackProps) {
  const topCard = cards[cards.length - 1]
  const metadata = topCard ? cardsById[topCard.cardId] : null

  return (
    <div
      onDragOver={(event) => event.preventDefault()}
      onDrop={() => onDropCard(playerId, zone)}
      className="rounded-[1.5rem] border border-white/10 bg-black/20 p-4"
    >
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-[0.24em] text-zinc-400">{title}</p>
        <span className="inline-flex items-center gap-2 text-xs text-zinc-200">
          <Layers3 className="size-4" />
          {cards.length}
        </span>
      </div>

      <button
        type="button"
        className="mt-4 flex h-32 w-full items-center justify-center rounded-[1.5rem] border border-dashed border-white/10 bg-white/5 text-center text-sm text-zinc-300 transition hover:border-amber-200/30"
        onClick={() => onCardClick(topCard?.instanceId ?? null)}
        draggable={Boolean(topCard)}
        onDragStart={() => {
          if (topCard) {
            onDragStart(playerId, zone, topCard.instanceId)
          }
        }}
      >
        {topCard && metadata ? metadata.name : `Drop cards into ${title.toLowerCase()}`}
      </button>
    </div>
  )
}
