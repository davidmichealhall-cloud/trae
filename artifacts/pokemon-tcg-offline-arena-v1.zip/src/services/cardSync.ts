import { appDb } from '@/db/appDb'
import { fetchAllCards, SYNC_VERSION, TCGDEX_SOURCE } from '@/services/tcgdexApi'
import type { SyncMeta } from '@/types/tcg'

export type SyncProgress = {
  status: 'idle' | 'syncing' | 'success' | 'error'
  message: string
  page: number
  totalCards: number
  lastSyncedAt: number | null
}

export async function getSyncMeta() {
  return appDb.syncMeta.get('cards')
}

export async function getCachedCounts() {
  const [cardCount, setCount, deckCount] = await Promise.all([
    appDb.cards.count(),
    appDb.sets.count(),
    appDb.decks.count(),
  ])

  return { cardCount, setCount, deckCount }
}

export async function shouldRunInitialSync() {
  const [meta, cardCount] = await Promise.all([getSyncMeta(), appDb.cards.count()])

  if (!meta || !cardCount) {
    return true
  }

  const oneDay = 1000 * 60 * 60 * 24
  return Date.now() - meta.lastSyncedAt > oneDay
}

export async function syncAllCards(
  onProgress?: (progress: SyncProgress) => void,
) {
  onProgress?.({
    status: 'syncing',
    message: 'Starting TCGdex sync...',
    page: 0,
    totalCards: 0,
    lastSyncedAt: null,
  })

  const result = await fetchAllCards()
  const chunkSize = 500

  await appDb.transaction('rw', appDb.cards, appDb.sets, async () => {
    await appDb.cards.clear()
    await appDb.sets.clear()
  })

  for (let offset = 0; offset < result.cards.length; offset += chunkSize) {
    const cardsChunk = result.cards.slice(offset, offset + chunkSize)
    const start = offset
    const end = offset + cardsChunk.length
    onProgress?.({
      status: 'syncing',
      message: `Persisting cards ${start + 1}-${end} of ${result.cards.length}`,
      page: Math.floor(offset / chunkSize) + 1,
      totalCards: end,
      lastSyncedAt: null,
    })

    await appDb.cards.bulkPut(cardsChunk)
  }

  await appDb.sets.bulkPut(result.sets)

  const meta: SyncMeta = {
    key: 'cards',
    lastSyncedAt: Date.now(),
    cardCount: result.cards.length,
    source: TCGDEX_SOURCE,
    version: SYNC_VERSION,
  }

  await appDb.syncMeta.put(meta)

  onProgress?.({
    status: 'success',
    message: `Synced ${result.cards.length} cards`,
    page: Math.ceil(result.cards.length / chunkSize),
    totalCards: result.cards.length,
    lastSyncedAt: meta.lastSyncedAt,
  })

  return meta
}
