import { appDb } from '@/db/appDb'
import type { CachedCard, CardFilterState, SavedDeck } from '@/types/tcg'

export async function loadFilterOptions() {
  const [sets, cards] = await Promise.all([
    appDb.sets.orderBy('name').toArray(),
    appDb.cards.toArray(),
  ])

  const types = [...new Set(cards.flatMap((card) => card.types))].sort((left, right) =>
    left.localeCompare(right),
  )

  return { sets, types }
}

export async function searchLocalCards(
  filters: CardFilterState,
  limit = 120,
): Promise<CachedCard[]> {
  const normalizedSearch = filters.search.trim().toLowerCase()

  let cards = await appDb.cards.toArray()

  if (filters.setId) {
    cards = cards.filter((card) => card.setId === filters.setId)
  }

  if (filters.type) {
    cards = cards.filter((card) => card.types.includes(filters.type))
  }

  if (normalizedSearch) {
    cards = cards.filter((card) => {
      return (
        card.name.toLowerCase().includes(normalizedSearch) ||
        card.setName.toLowerCase().includes(normalizedSearch)
      )
    })
  }

  return cards
    .sort((left, right) => left.name.localeCompare(right.name))
    .slice(0, limit)
}

export async function getCardById(cardId: string) {
  return appDb.cards.get(cardId)
}

export async function loadAllCachedCards() {
  return appDb.cards.toArray()
}

export async function loadCardsBySetId(setId: string) {
  return appDb.cards
    .filter((card) => card.setId === setId)
    .sortBy('name')
}

export async function listDecks() {
  return appDb.decks.orderBy('updatedAt').reverse().toArray()
}

export async function saveDeck(deck: SavedDeck) {
  await appDb.decks.put(deck)
}

export async function deleteDeck(deckId: string) {
  await appDb.decks.delete(deckId)
}
