import type { CachedCard, CachedSet, TcgdexGraphQlResponse } from '@/types/tcg'
import { resolveTcgdexImageUrl } from '@/utils/images'

const GRAPHQL_ENDPOINT = 'https://api.tcgdex.net/v2/graphql'
export const TCGDEX_SOURCE = 'tcgdex-graphql-en'
export const SYNC_VERSION = '1'

type GraphQlCardsPayload = {
  cards: Array<{
    id: string
    localId: string
    name: string
    image: string | null
    hp: number | null
    types: string[] | null
    stage: string | null
    category: string
    regulationMark: string | null
    energyType: string | null
    evolveFrom: string | null
    attacks:
      | Array<{
          name: string
          cost: string[] | null
          damage: string | null
          effect: string | null
        } | null>
      | null
    set: {
      id: string
      name: string
      logo: string | null
      symbol: string | null
    }
  }>
}

const CARD_SYNC_QUERY = `
  query AllCards {
    cards {
      id
      localId
      name
      image
      hp
      types
      stage
      category
      regulationMark
      energyType
      evolveFrom
      attacks {
        name
        cost
        damage
        effect
      }
      set {
        id
        name
        logo
        symbol
      }
    }
  }
`

async function postGraphQl<T>(
  query: string,
  variables?: Record<string, number>,
): Promise<T> {
  const response = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: JSON.stringify({ query, variables }),
  })

  if (!response.ok) {
    throw new Error(`TCGdex request failed with status ${response.status}`)
  }

  const payload = (await response.json()) as TcgdexGraphQlResponse<T>

  if (payload.errors?.length && !payload.data) {
    throw new Error(payload.errors.map((entry) => entry.message).join(', '))
  }

  if (!payload.data) {
    throw new Error('TCGdex returned an empty payload')
  }

  if (payload.errors?.length) {
    console.warn('TCGdex GraphQL returned partial errors during sync', payload.errors)
  }

  return payload.data
}

function normalizeCard(card: GraphQlCardsPayload['cards'][number]): CachedCard {
  return {
    id: card.id,
    localId: card.localId,
    name: card.name,
    imageUrl: resolveTcgdexImageUrl(card.image ?? null),
    hp: card.hp ? String(card.hp) : null,
    types: card.types ?? [],
    attacks: (card.attacks ?? [])
      .filter((attack): attack is NonNullable<typeof attack> => Boolean(attack?.name))
      .map((attack) => ({
        name: attack.name,
        cost: attack.cost ?? [],
        damage: attack.damage ?? null,
        effect: attack.effect ?? null,
      })),
    setId: card.set.id,
    setName: card.set.name,
    stage: card.stage ?? null,
    regulationMark: card.regulationMark ?? null,
    category: card.category,
    energyType: card.energyType ?? null,
    evolvesFrom: card.evolveFrom ?? null,
    cachedAt: Date.now(),
  }
}

function normalizeSet(card: GraphQlCardsPayload['cards'][number]): CachedSet {
  return {
    id: card.set.id,
    name: card.set.name,
    logo: card.set.logo ?? null,
    symbol: card.set.symbol ?? null,
  }
}

export async function fetchAllCards() {
  const data = await postGraphQl<GraphQlCardsPayload>(CARD_SYNC_QUERY)

  const cards = data.cards.map(normalizeCard)
  const setsMap = new Map<string, CachedSet>()

  data.cards.forEach((card) => {
    setsMap.set(card.set.id, normalizeSet(card))
  })

  return {
    cards,
    sets: [...setsMap.values()],
  }
}
