import { appDb } from '@/db/appDb'
import type { ExportSettingsRecord, ImageSaveMode } from '@/types/tcg'

type DirectoryPickerWindow = Window &
  typeof globalThis & {
    showDirectoryPicker?: (options?: {
      id?: string
      mode?: 'read' | 'readwrite'
    }) => Promise<FileSystemDirectoryHandle>
  }

export const EXPORT_SETTINGS_KEY = 'image-export'

export const DEFAULT_EXPORT_SETTINGS: ExportSettingsRecord = {
  key: EXPORT_SETTINGS_KEY,
  saveMode: 'browser-download',
  preferredDirectoryName: null,
  preferredDirectoryHandle: null,
}

export function supportsDirectoryPicker() {
  return typeof window !== 'undefined' && 'showDirectoryPicker' in window
}

export function supportsSavePicker() {
  return typeof window !== 'undefined' && 'showSaveFilePicker' in window
}

export function isPickerAbortError(error: unknown) {
  return (
    error instanceof DOMException
      ? error.name === 'AbortError'
      : error instanceof Error
        ? /aborted a request/i.test(error.message)
        : false
  )
}

export async function loadExportSettings() {
  const savedSettings = await appDb.settings.get(EXPORT_SETTINGS_KEY)

  return {
    ...DEFAULT_EXPORT_SETTINGS,
    ...savedSettings,
  } satisfies ExportSettingsRecord
}

export async function saveExportSettings(settings: ExportSettingsRecord) {
  await appDb.settings.put(settings)
  return settings
}

export async function updateExportSaveMode(
  settings: ExportSettingsRecord,
  saveMode: ImageSaveMode,
) {
  const nextSettings = {
    ...settings,
    saveMode,
  } satisfies ExportSettingsRecord

  await saveExportSettings(nextSettings)
  return nextSettings
}

export async function choosePreferredDirectory(settings: ExportSettingsRecord) {
  if (!supportsDirectoryPicker()) {
    throw new Error('Folder selection is not supported in this browser')
  }

  const pickerWindow = window as DirectoryPickerWindow
  const directoryHandle = await pickerWindow.showDirectoryPicker?.({
    id: 'pokemon-card-exports',
    mode: 'readwrite',
  })

  if (!directoryHandle) {
    throw new Error('Folder selection is not supported in this browser')
  }

  const nextSettings = {
    ...settings,
    saveMode: 'preferred-folder',
    preferredDirectoryHandle: directoryHandle,
    preferredDirectoryName: directoryHandle.name,
  } satisfies ExportSettingsRecord

  await saveExportSettings(nextSettings)
  return nextSettings
}

export async function clearPreferredDirectory(settings: ExportSettingsRecord) {
  const nextSettings = {
    ...settings,
    preferredDirectoryHandle: null,
    preferredDirectoryName: null,
    saveMode: settings.saveMode === 'preferred-folder' ? 'browser-download' : settings.saveMode,
  } satisfies ExportSettingsRecord

  await saveExportSettings(nextSettings)
  return nextSettings
}
