import type { CardInstance, DeckEntry, PlayerBoard, SavedDeck } from '@/types/tcg'
import { createId } from '@/utils/id'

type DeckLibrary = Record<string, SavedDeck>

export function shuffleCards<T>(items: T[]) {
  const clone = [...items]

  for (let index = clone.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1))
    ;[clone[index], clone[swapIndex]] = [clone[swapIndex], clone[index]]
  }

  return clone
}

function createInstance(cardId: string): CardInstance {
  return {
    instanceId: createId('card'),
    cardId,
    attachedEnergy: 0,
    damage: 0,
    statuses: [],
    notes: '',
  }
}

export function expandDeckEntries(entries: DeckEntry[]) {
  return entries.flatMap((entry) =>
    Array.from({ length: entry.quantity }, () => createInstance(entry.cardId)),
  )
}

function createEmptyPlayer(playerId: PlayerBoard['playerId']): PlayerBoard {
  return {
    playerId,
    deckId: null,
    deckName: 'No deck loaded',
    deck: [],
    hand: [],
    discard: [],
    prizes: [],
    bench: [null, null, null, null, null],
    active: null,
  }
}

export function createEmptyBoards() {
  return {
    player1: createEmptyPlayer('player1'),
    player2: createEmptyPlayer('player2'),
  }
}

export function buildPlayerFromDeck(playerId: PlayerBoard['playerId'], deck: SavedDeck): PlayerBoard {
  const expandedCards = shuffleCards(expandDeckEntries(deck.cards))
  const hand = expandedCards.slice(0, 7)
  const prizes = expandedCards.slice(7, 13)
  const deckPile = expandedCards.slice(13)

  return {
    playerId,
    deckId: deck.id,
    deckName: deck.name,
    deck: deckPile,
    hand,
    discard: [],
    prizes,
    bench: [null, null, null, null, null],
    active: null,
  }
}

export function buildBoardsFromDecks(
  deckIds: { player1: string | null; player2: string | null },
  decks: DeckLibrary,
) {
  return {
    player1: deckIds.player1 && decks[deckIds.player1]
      ? buildPlayerFromDeck('player1', decks[deckIds.player1])
      : createEmptyPlayer('player1'),
    player2: deckIds.player2 && decks[deckIds.player2]
      ? buildPlayerFromDeck('player2', decks[deckIds.player2])
      : createEmptyPlayer('player2'),
  }
}
