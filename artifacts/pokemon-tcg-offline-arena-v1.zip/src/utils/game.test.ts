import { describe, expect, it, vi } from 'vitest'

import type { SavedDeck } from '@/types/tcg'
import { buildBoardsFromDecks, expandDeckEntries, shuffleCards } from '@/utils/game'

describe('game utilities', () => {
  it('expands deck entries into individual card instances', () => {
    const instances = expandDeckEntries([
      { cardId: 'a', quantity: 2 },
      { cardId: 'b', quantity: 1 },
    ])

    expect(instances).toHaveLength(3)
    expect(new Set(instances.map((entry) => entry.instanceId)).size).toBe(3)
  })

  it('builds player boards with opening hand, prizes, and deck pile', () => {
    vi.spyOn(Math, 'random').mockReturnValue(0.5)

    const filledDeck: SavedDeck = {
      id: 'deck-1',
      name: 'Opening Test',
      cards: [{ cardId: 'x', quantity: 60 }],
      createdAt: 0,
      updatedAt: 0,
    }

    const boards = buildBoardsFromDecks(
      { player1: filledDeck.id, player2: null },
      { [filledDeck.id]: filledDeck },
    )

    expect(boards.player1.hand).toHaveLength(7)
    expect(boards.player1.prizes).toHaveLength(6)
    expect(boards.player1.deck).toHaveLength(47)
    expect(boards.player2.deckName).toBe('No deck loaded')

    vi.restoreAllMocks()
  })

  it('keeps shuffle result length stable', () => {
    expect(shuffleCards([1, 2, 3, 4]).sort()).toEqual([1, 2, 3, 4])
  })
})
