import type { CachedCard, ExportSettingsRecord } from '@/types/tcg'
import { resolveTcgdexImageUrl } from '@/utils/images'

type PermissionAwareDirectoryHandle = FileSystemDirectoryHandle & {
  queryPermission?: (descriptor: { mode: 'read' | 'readwrite' }) => Promise<PermissionState>
  requestPermission?: (descriptor: { mode: 'read' | 'readwrite' }) => Promise<PermissionState>
}

type SavePickerWindow = Window &
  typeof globalThis & {
    showSaveFilePicker?: (options?: {
      id?: string
      suggestedName?: string
      types?: Array<{
        description: string
        accept: Record<string, string[]>
      }>
    }) => Promise<FileSystemFileHandle>
  }

const CARD_EXPORT_WIDTH = 750
const CARD_EXPORT_HEIGHT = 1050

async function fetchCardImageBlob(imageUrl: string) {
  const response = await fetch(imageUrl, { mode: 'cors' })

  if (!response.ok) {
    throw new Error(`Image request failed with status ${response.status}`)
  }

  return response.blob()
}

async function convertBlobToJpeg(blob: Blob) {
  const bitmap = await createImageBitmap(blob)
  const canvas = document.createElement('canvas')
  canvas.width = CARD_EXPORT_WIDTH
  canvas.height = CARD_EXPORT_HEIGHT

  const context = canvas.getContext('2d')

  if (!context) {
    throw new Error('Canvas is not available')
  }

  context.fillStyle = '#ffffff'
  context.fillRect(0, 0, canvas.width, canvas.height)
  context.imageSmoothingEnabled = true
  context.imageSmoothingQuality = 'high'

  const sourceRatio = bitmap.width / bitmap.height
  const targetRatio = canvas.width / canvas.height

  let drawWidth = canvas.width
  let drawHeight = canvas.height
  let drawX = 0
  let drawY = 0

  if (sourceRatio > targetRatio) {
    drawHeight = canvas.height
    drawWidth = drawHeight * sourceRatio
    drawX = (canvas.width - drawWidth) / 2
  } else {
    drawWidth = canvas.width
    drawHeight = drawWidth / sourceRatio
    drawY = (canvas.height - drawHeight) / 2
  }

  context.drawImage(bitmap, drawX, drawY, drawWidth, drawHeight)

  const jpegBlob = await new Promise<Blob | null>((resolve) => {
    canvas.toBlob((value) => resolve(value), 'image/jpeg', 0.94)
  })

  bitmap.close()

  if (!jpegBlob) {
    throw new Error('Unable to convert image to JPEG')
  }

  return jpegBlob
}

function canvasToJpegBlob(canvas: HTMLCanvasElement) {
  return new Promise<Blob | null>((resolve) => {
    canvas.toBlob((value) => resolve(value), 'image/jpeg', 0.94)
  })
}

function sanitizeFileName(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
}

function createCardFileName(
  card: CachedCard,
  options?: {
    includeSetName?: boolean
    includeLocalId?: boolean
  },
) {
  const parts = [
    options?.includeSetName ? sanitizeFileName(card.setName) : '',
    options?.includeLocalId ? sanitizeFileName(card.localId || card.id) : '',
    sanitizeFileName(card.name) || 'pokemon-card',
  ].filter(Boolean)

  return `${parts.join('-')}.jpeg`
}

export type SavedImageResult = {
  fileName: string
  previewUrl?: string
  locationLabel: string
}

export type BulkSaveResult = {
  savedCount: number
  locationLabel: string
}

function getCardPalette(card: CachedCard) {
  const primaryType = card.types[0] ?? card.energyType ?? 'Colorless'

  switch (primaryType) {
    case 'Fire':
      return { top: '#7f1d1d', bottom: '#431407', accent: '#fb923c' }
    case 'Water':
      return { top: '#1d4ed8', bottom: '#172554', accent: '#7dd3fc' }
    case 'Grass':
      return { top: '#166534', bottom: '#052e16', accent: '#86efac' }
    case 'Lightning':
      return { top: '#854d0e', bottom: '#422006', accent: '#fde047' }
    case 'Psychic':
      return { top: '#7e22ce', bottom: '#3b0764', accent: '#f0abfc' }
    case 'Darkness':
      return { top: '#27272a', bottom: '#09090b', accent: '#d4d4d8' }
    case 'Metal':
      return { top: '#52525b', bottom: '#18181b', accent: '#e4e4e7' }
    case 'Fighting':
      return { top: '#9a3412', bottom: '#431407', accent: '#fdba74' }
    case 'Dragon':
      return { top: '#1d4ed8', bottom: '#4c1d95', accent: '#c4b5fd' }
    case 'Fairy':
      return { top: '#be185d', bottom: '#500724', accent: '#f9a8d4' }
    default:
      return { top: '#92400e', bottom: '#111827', accent: '#fcd34d' }
  }
}

function drawRoundedRect(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
  fill: string,
  stroke?: string,
) {
  context.beginPath()
  context.moveTo(x + radius, y)
  context.lineTo(x + width - radius, y)
  context.quadraticCurveTo(x + width, y, x + width, y + radius)
  context.lineTo(x + width, y + height - radius)
  context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
  context.lineTo(x + radius, y + height)
  context.quadraticCurveTo(x, y + height, x, y + height - radius)
  context.lineTo(x, y + radius)
  context.quadraticCurveTo(x, y, x + radius, y)
  context.closePath()

  context.fillStyle = fill
  context.fill()

  if (stroke) {
    context.strokeStyle = stroke
    context.lineWidth = 2
    context.stroke()
  }
}

function wrapText(context: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(/\s+/)
  const lines: string[] = []
  let currentLine = ''

  words.forEach((word) => {
    const candidate = currentLine ? `${currentLine} ${word}` : word

    if (context.measureText(candidate).width <= maxWidth || !currentLine) {
      currentLine = candidate
      return
    }

    lines.push(currentLine)
    currentLine = word
  })

  if (currentLine) {
    lines.push(currentLine)
  }

  return lines
}

async function renderOfflineCardJpeg(card: CachedCard) {
  const canvas = document.createElement('canvas')
  canvas.width = CARD_EXPORT_WIDTH
  canvas.height = CARD_EXPORT_HEIGHT

  const context = canvas.getContext('2d')

  if (!context) {
    throw new Error('Canvas is not available')
  }

  const palette = getCardPalette(card)
  const backgroundGradient = context.createLinearGradient(0, 0, canvas.width, canvas.height)
  backgroundGradient.addColorStop(0, palette.top)
  backgroundGradient.addColorStop(1, palette.bottom)
  context.fillStyle = backgroundGradient
  context.fillRect(0, 0, canvas.width, canvas.height)

  const glowGradient = context.createRadialGradient(120, 80, 30, 120, 80, 380)
  glowGradient.addColorStop(0, `${palette.accent}55`)
  glowGradient.addColorStop(1, '#00000000')
  context.fillStyle = glowGradient
  context.fillRect(0, 0, canvas.width, canvas.height)

  drawRoundedRect(context, 24, 24, canvas.width - 48, canvas.height - 48, 30, '#0c0a09dd', '#fcd34d66')
  drawRoundedRect(context, 46, 170, canvas.width - 92, 360, 28, '#ffffff10', '#ffffff20')

  context.fillStyle = '#fef3c7'
  context.font = '700 28px sans-serif'
  context.fillText('OFFLINE CACHE', 60, 86)

  context.font = '700 52px sans-serif'
  const titleLines = wrapText(context, card.name, 470).slice(0, 2)
  titleLines.forEach((line, index) => {
    context.fillText(line, 60, 146 + index * 58)
  })

  drawRoundedRect(context, 552, 62, 132, 58, 29, '#fef3c722')
  context.font = '700 28px sans-serif'
  context.fillStyle = '#fefce8'
  context.textAlign = 'center'
  context.fillText(`HP ${card.hp ?? '--'}`, 618, 100)
  context.textAlign = 'start'

  context.fillStyle = '#f8fafc'
  context.font = '600 24px sans-serif'
  context.fillText(card.setName, 70, 590)
  context.fillStyle = '#d4d4d8'
  context.font = '500 20px sans-serif'
  context.fillText(card.category, 70, 626)
  context.fillText(card.stage ?? 'Basic', 300, 626)

  const chips = [...(card.types.length ? card.types : ['Colorless']), card.regulationMark ?? 'Local']
  let chipX = 60
  let chipY = 670

  context.font = '600 20px sans-serif'
  chips.forEach((chip) => {
    const chipWidth = context.measureText(chip).width + 34

    if (chipX + chipWidth > canvas.width - 60) {
      chipX = 60
      chipY += 56
    }

    drawRoundedRect(context, chipX, chipY, chipWidth, 40, 20, '#ffffff14', '#ffffff22')
    context.fillStyle = '#fafaf9'
    context.fillText(chip, chipX + 17, chipY + 26)
    chipX += chipWidth + 14
  })

  const attacks = (card.attacks.length
    ? card.attacks
    : [{ name: 'No attack data', cost: [], damage: null, effect: null }]).slice(0, 3)

  let attackY = 760
  attacks.forEach((attack) => {
    drawRoundedRect(context, 60, attackY, canvas.width - 120, 96, 24, '#00000044', '#ffffff18')
    context.fillStyle = '#fef3c7'
    context.font = '700 24px sans-serif'
    context.fillText(attack.name, 84, attackY + 36)

    if (attack.damage) {
      context.textAlign = 'end'
      context.fillText(attack.damage, canvas.width - 88, attackY + 36)
      context.textAlign = 'start'
    }

    const secondaryLine = attack.cost.length
      ? `Cost: ${attack.cost.join(' • ')}`
      : attack.effect ?? 'Manual sandbox card'

    context.fillStyle = '#e4e4e7'
    context.font = '500 18px sans-serif'
    wrapText(context, secondaryLine, canvas.width - 168)
      .slice(0, 2)
      .forEach((line, index) => {
        context.fillText(line, 84, attackY + 68 + index * 22)
      })

    attackY += 112
  })

  context.fillStyle = '#a1a1aa'
  context.font = '600 18px sans-serif'
  context.fillText('Generated from cached card data for offline export.', 60, canvas.height - 72)

  const jpegBlob = await canvasToJpegBlob(canvas)

  if (!jpegBlob) {
    throw new Error('Unable to convert image to JPEG')
  }

  return jpegBlob
}

async function createCardJpeg(card: CachedCard) {
  const resolvedImageUrl = resolveTcgdexImageUrl(card.imageUrl)

  if (resolvedImageUrl) {
    try {
      const sourceBlob = await fetchCardImageBlob(resolvedImageUrl)
      return await convertBlobToJpeg(sourceBlob)
    } catch {
      return renderOfflineCardJpeg(card)
    }
  }

  return renderOfflineCardJpeg(card)
}

async function saveWithBrowserDownload(blob: Blob, fileName: string, preview = true) {
  const objectUrl = URL.createObjectURL(blob)
  const anchor = document.createElement('a')

  anchor.href = objectUrl
  anchor.download = fileName
  anchor.click()

  if (!preview) {
    window.setTimeout(() => {
      URL.revokeObjectURL(objectUrl)
    }, 1000)
  }

  return {
    previewUrl: preview ? objectUrl : undefined,
    locationLabel: 'browser downloads',
  }
}

async function saveWithPreferredDirectory(
  blob: Blob,
  fileName: string,
  directoryHandle: FileSystemDirectoryHandle,
  directoryName: string | null,
  options?: {
    preferredSubdirectoryName?: string
    preview?: boolean
  },
) {
  const permissionAwareHandle = directoryHandle as PermissionAwareDirectoryHandle
  const permission = permissionAwareHandle.queryPermission
    ? await permissionAwareHandle.queryPermission({ mode: 'readwrite' })
    : 'prompt'
  const grantedPermission =
    permission === 'granted'
      ? permission
      : permissionAwareHandle.requestPermission
        ? await permissionAwareHandle.requestPermission({ mode: 'readwrite' })
        : 'granted'

  if (grantedPermission !== 'granted') {
    throw new Error('Write permission was not granted for the selected folder')
  }

  const targetDirectoryHandle = options?.preferredSubdirectoryName
    ? await directoryHandle.getDirectoryHandle(options.preferredSubdirectoryName, { create: true })
    : directoryHandle
  const fileHandle = await targetDirectoryHandle.getFileHandle(fileName, { create: true })
  const writable = await fileHandle.createWritable()
  await writable.write(blob)
  await writable.close()

  const previewUrl = options?.preview === false ? undefined : URL.createObjectURL(blob)

  return {
    previewUrl,
    locationLabel: options?.preferredSubdirectoryName
      ? `${directoryName ?? 'preferred folder'}/${options.preferredSubdirectoryName}`
      : directoryName ?? 'preferred folder',
  }
}

async function saveWithPicker(blob: Blob, fileName: string, preview = true) {
  const pickerWindow = window as SavePickerWindow

  if (!pickerWindow.showSaveFilePicker) {
    return saveWithBrowserDownload(blob, fileName, preview)
  }

  const suggestedHandle = await pickerWindow.showSaveFilePicker({
    id: 'pokemon-card-image',
    suggestedName: fileName,
    types: [
      {
        description: 'JPEG image',
        accept: {
          'image/jpeg': ['.jpeg', '.jpg'],
        },
      },
    ],
  })

  const writable = await suggestedHandle.createWritable()
  await writable.write(blob)
  await writable.close()

  const previewUrl = preview ? URL.createObjectURL(blob) : undefined

  return {
    previewUrl,
    locationLabel: 'your chosen location',
  }
}

export async function saveCardImageAsJpeg(
  card: CachedCard,
  settings: ExportSettingsRecord,
): Promise<SavedImageResult> {
  const jpegBlob = await createCardJpeg(card)
  const fileName = createCardFileName(card)

  if (settings.saveMode === 'preferred-folder' && settings.preferredDirectoryHandle) {
    const preferredSave = await saveWithPreferredDirectory(
      jpegBlob,
      fileName,
      settings.preferredDirectoryHandle,
      settings.preferredDirectoryName,
      { preview: true },
    )

    return {
      fileName,
      ...preferredSave,
    }
  }

  if (settings.saveMode === 'ask-every-time') {
    const pickerSave = await saveWithPicker(jpegBlob, fileName, true)
    return {
      fileName,
      ...pickerSave,
    }
  }

  const browserSave = await saveWithBrowserDownload(jpegBlob, fileName, true)
  return {
    fileName,
    ...browserSave,
  }
}

export async function saveSetImagesAsJpegs(
  cards: CachedCard[],
  settings: ExportSettingsRecord,
  setName: string,
): Promise<BulkSaveResult> {
  if (!cards.length) {
    throw new Error('There are no cards in this set to save')
  }

  if (settings.saveMode === 'ask-every-time') {
    throw new Error('Bulk set export is not available with "Ask every time". Use browser downloads or a preferred folder instead.')
  }

  const setFolderName = sanitizeFileName(setName) || 'pokemon-set'
  let locationLabel = settings.preferredDirectoryName ?? 'browser downloads'

  for (const card of cards) {
    const jpegBlob = await createCardJpeg(card)
    const fileName = createCardFileName(card, {
      includeSetName: settings.saveMode !== 'preferred-folder',
      includeLocalId: true,
    })

    if (settings.saveMode === 'preferred-folder' && settings.preferredDirectoryHandle) {
      const savedResult = await saveWithPreferredDirectory(
        jpegBlob,
        fileName,
        settings.preferredDirectoryHandle,
        settings.preferredDirectoryName,
        {
          preferredSubdirectoryName: setFolderName,
          preview: false,
        },
      )

      locationLabel = savedResult.locationLabel
      continue
    }

    const savedResult = await saveWithBrowserDownload(jpegBlob, fileName, false)
    locationLabel = savedResult.locationLabel
  }

  return {
    savedCount: cards.length,
    locationLabel,
  }
}

export async function copyCardImageToClipboard(card: CachedCard) {
  if (typeof ClipboardItem === 'undefined' || !navigator.clipboard?.write) {
    throw new Error('Image clipboard is not supported in this browser')
  }

  const jpegBlob = await createCardJpeg(card)

  await navigator.clipboard.write([
    new ClipboardItem({
      'image/jpeg': jpegBlob,
    }),
  ])
}
