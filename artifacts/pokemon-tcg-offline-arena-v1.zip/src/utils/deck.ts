import type { CachedCard, DeckEntry, SavedDeck } from '@/types/tcg'
import { createId } from '@/utils/id'

export type DeckValidation = {
  totalCards: number
  isValid: boolean
  issues: string[]
}

export function countDeckCards(entries: DeckEntry[]) {
  return entries.reduce((total, entry) => total + entry.quantity, 0)
}

export function validateDeck(entries: DeckEntry[], cardsById: Record<string, CachedCard>) {
  const totalCards = countDeckCards(entries)
  const issues: string[] = []

  if (totalCards !== 60) {
    issues.push('Deck must contain exactly 60 cards.')
  }

  entries.forEach((entry) => {
    const card = cardsById[entry.cardId]

    if (!card) {
      issues.push(`Card ${entry.cardId} is missing from the local cache.`)
      return
    }

    const isBasicEnergy =
      card.category === 'Energy' &&
      card.name.toLowerCase().endsWith('energy') &&
      !card.attacks.length

    if (!isBasicEnergy && entry.quantity > 4) {
      issues.push(`${card.name} exceeds the 4-copy limit.`)
    }
  })

  return {
    totalCards,
    isValid: issues.length === 0,
    issues,
  } satisfies DeckValidation
}

export function upsertDeckEntry(entries: DeckEntry[], cardId: string, delta: number) {
  const map = new Map(entries.map((entry) => [entry.cardId, { ...entry }]))
  const current = map.get(cardId)
  const nextQuantity = Math.max(0, (current?.quantity ?? 0) + delta)

  if (!nextQuantity) {
    map.delete(cardId)
  } else {
    map.set(cardId, { cardId, quantity: nextQuantity })
  }

  return [...map.values()].sort((left, right) => left.cardId.localeCompare(right.cardId))
}

export function createDeckRecord(name: string, cards: DeckEntry[], existingId?: string): SavedDeck {
  const timestamp = Date.now()

  return {
    id: existingId ?? createId('deck'),
    name: name.trim() || 'Untitled Deck',
    cards,
    createdAt: timestamp,
    updatedAt: timestamp,
  }
}
