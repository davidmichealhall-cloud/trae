export function resolveTcgdexImageUrl(imageUrl: string | null) {
  if (!imageUrl) {
    return null
  }

  if (/\.(png|webp|jpg|jpeg)$/i.test(imageUrl)) {
    return imageUrl
  }

  return `${imageUrl.replace(/\/$/, '')}/high.webp`
}
