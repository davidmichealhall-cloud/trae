import { describe, expect, it } from 'vitest'

import type { CachedCard } from '@/types/tcg'
import { upsertDeckEntry, validateDeck } from '@/utils/deck'

const pokemonCard: CachedCard = {
  id: 'sv1-1',
  localId: '1',
  name: 'Bulbasaur',
  imageUrl: null,
  hp: '70',
  types: ['Grass'],
  attacks: [],
  setId: 'sv1',
  setName: 'Scarlet & Violet',
  stage: 'Basic',
  regulationMark: 'G',
  category: 'Pokemon',
  energyType: null,
  evolvesFrom: null,
  cachedAt: 0,
}

const energyCard: CachedCard = {
  ...pokemonCard,
  id: 'energy-1',
  name: 'Grass Energy',
  category: 'Energy',
}

describe('deck utilities', () => {
  it('enforces 60 cards and the 4-copy rule for non-basic-energy cards', () => {
    const result = validateDeck(
      [
        { cardId: pokemonCard.id, quantity: 5 },
        { cardId: energyCard.id, quantity: 55 },
      ],
      {
        [pokemonCard.id]: pokemonCard,
        [energyCard.id]: energyCard,
      },
    )

    expect(result.totalCards).toBe(60)
    expect(result.isValid).toBe(false)
    expect(result.issues[0]).toContain('4-copy limit')
  })

  it('upserts and removes deck entries without duplicates', () => {
    const entries = upsertDeckEntry([], pokemonCard.id, 1)
    const incremented = upsertDeckEntry(entries, pokemonCard.id, 1)
    const removed = upsertDeckEntry(incremented, pokemonCard.id, -2)

    expect(entries).toEqual([{ cardId: pokemonCard.id, quantity: 1 }])
    expect(incremented).toEqual([{ cardId: pokemonCard.id, quantity: 2 }])
    expect(removed).toEqual([])
  })
})
