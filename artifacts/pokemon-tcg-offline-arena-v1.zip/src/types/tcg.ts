export type AppMode = 'sync' | 'builder' | 'playmat'

export type CardAttack = {
  name: string
  cost: string[]
  damage: string | null
  effect: string | null
}

export type CachedSet = {
  id: string
  name: string
  logo: string | null
  symbol: string | null
}

export type CachedCard = {
  id: string
  localId: string
  name: string
  imageUrl: string | null
  hp: string | null
  types: string[]
  attacks: CardAttack[]
  setId: string
  setName: string
  stage: string | null
  regulationMark: string | null
  category: string
  energyType: string | null
  evolvesFrom: string | null
  cachedAt: number
}

export type SyncMeta = {
  key: 'cards'
  lastSyncedAt: number
  cardCount: number
  source: string
  version: string
}

export type DeckEntry = {
  cardId: string
  quantity: number
}

export type SavedDeck = {
  id: string
  name: string
  cards: DeckEntry[]
  createdAt: number
  updatedAt: number
}

export type CardFilterState = {
  search: string
  type: string
  setId: string
}

export type ImageSaveMode = 'browser-download' | 'ask-every-time' | 'preferred-folder'

export type ExportSettingsRecord = {
  key: 'image-export'
  saveMode: ImageSaveMode
  preferredDirectoryName: string | null
  preferredDirectoryHandle?: FileSystemDirectoryHandle | null
}

export type SyncStatus = 'idle' | 'syncing' | 'success' | 'error'

export type ManualStatus =
  | 'Asleep'
  | 'Burned'
  | 'Confused'
  | 'Paralyzed'
  | 'Poisoned'

export type CardInstance = {
  instanceId: string
  cardId: string
  attachedEnergy: number
  damage: number
  statuses: ManualStatus[]
  notes: string
}

export type PlayerBoard = {
  playerId: 'player1' | 'player2'
  deckId: string | null
  deckName: string
  deck: CardInstance[]
  hand: CardInstance[]
  discard: CardInstance[]
  prizes: CardInstance[]
  bench: Array<CardInstance | null>
  active: CardInstance | null
}

export type ZoneType =
  | 'deck'
  | 'hand'
  | 'discard'
  | 'prizes'
  | 'bench'
  | 'active'

export type DragPayload = {
  playerId: PlayerBoard['playerId']
  zone: ZoneType
  index?: number
  instanceId: string
}

export type GameStoreState = {
  currentPlayer: PlayerBoard['playerId']
  turnNumber: number
  selectedInstanceId: string | null
  players: Record<PlayerBoard['playerId'], PlayerBoard>
}

export type TcgdexGraphQlResponse<T> = {
  data?: T
  errors?: Array<{ message: string }>
}
